/**
 * @title Vault - 不可变的资金金库
 */
pragma solidity ^0.8.28;

// ==================== 内联 SafeERC20 库 (兼容非标准 ERC20) ====================
library SafeERC20 {
    function safeTransferFrom(
        address token,
        address from,
        address to,
        uint256 value
    ) internal {
        _callOptionalReturn(
            token,
            abi.encodeWithSelector(0x23b872dd, from, to, value)
        );
    }

    function safeTransfer(address token, address to, uint256 value) internal {
        _callOptionalReturn(
            token,
            abi.encodeWithSelector(0xa9059cbb, to, value)
        );
    }

    function _callOptionalReturn(address token, bytes memory data) private {
        require(_isContract(token), "SafeERC20: call to non-contract");
        (bool success, bytes memory returndata) = token.call(data);
        require(success, "SafeERC20: low-level call failed");
        if (returndata.length > 0) {
            require(
                abi.decode(returndata, (bool)),
                "SafeERC20: operation did not succeed"
            );
        }
    }

    function _isContract(address account) private view returns (bool) {
        uint256 size;
        assembly {
            size := extcodesize(account)
        }
        return size > 0;
    }
}

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);
}

contract Vault {
    using SafeERC20 for address;

    mapping(address => bool) public authorizedWithdrawers;

    event WithdrawerAuthorized(address indexed withdrawer, bool authorized);
    event TokensReceived(address indexed token, uint256 amount, address from);
    event TokensWithdrawn(
        address indexed token,
        uint256 amount,
        address indexed withdrawer,
        address indexed recipient
    );

    constructor(address initialWithdrawer) {
        require(initialWithdrawer != address(0), "Invalid withdrawer");
        authorizedWithdrawers[initialWithdrawer] = true;

        emit WithdrawerAuthorized(initialWithdrawer, true);
    }

    function setWithdrawerAuthorization(
        address withdrawer,
        bool authorized
    ) external {
        require(authorizedWithdrawers[msg.sender], "Not authorized withdrawer");
        require(withdrawer != address(0), "Invalid address");
        authorizedWithdrawers[withdrawer] = authorized;
        emit WithdrawerAuthorized(withdrawer, authorized);
    }

    /**
     * @dev 存入代币：自动处理手续费代币的余额差异
     */
    function receiveTokens(address token, uint256 amount) external {
        require(token != address(0), "Invalid token");
        require(amount > 0, "Amount must be > 0");

        uint256 balanceBefore = IERC20(token).balanceOf(address(this));
        token.safeTransferFrom(msg.sender, address(this), amount);
        uint256 balanceAfter = IERC20(token).balanceOf(address(this));

        require(balanceAfter > balanceBefore, "Balance did not increase");
        emit TokensReceived(token, balanceAfter - balanceBefore, msg.sender);
    }

    /**
     * @dev 提取 ERC20：仅限授权的 Withdrawer 调用
     */
    function withdrawTokens(
        address token,
        address recipient,
        uint256 amount
    ) external {
        require(authorizedWithdrawers[msg.sender], "Not authorized withdrawer");
        require(token != address(0), "Invalid token");
        require(recipient != address(0), "Invalid recipient");
        require(amount > 0, "Amount must be > 0");

        token.safeTransfer(recipient, amount);
        emit TokensWithdrawn(token, amount, msg.sender, recipient);
    }

    /**
     * @dev 提取 BNB：仅限授权的 Withdrawer 调用
     */
    function withdrawBNB(address payable recipient, uint256 amount) external {
        require(authorizedWithdrawers[msg.sender], "Not authorized withdrawer");
        require(recipient != address(0), "Invalid recipient");
        require(amount > 0, "Amount must be > 0");
        require(address(this).balance >= amount, "Insufficient balance");

        (bool success, bytes memory returnData) = recipient.call{value: amount}(
            ""
        );
        if (!success) {
            if (returnData.length > 0) {
                assembly {
                    revert(add(returnData, 32), mload(returnData))
                }
            }
            revert("BNB transfer failed");
        }
        emit TokensWithdrawn(address(0), amount, msg.sender, recipient);
    }

    receive() external payable {}

    function getTokenBalance(address token) external view returns (uint256) {
        if (token == address(0)) {
            return address(this).balance;
        }
        return IERC20(token).balanceOf(address(this));
    }

    function getBNBBalance() external view returns (uint256) {
        return address(this).balance;
    }
    function checkauthorizedWithdrawers(
        address withdrawer
    ) public view returns (bool) {
        // require(authorizedWithdrawers[withdrawer], "Not authorized withdrawer");
        return authorizedWithdrawers[withdrawer];
    }
}
