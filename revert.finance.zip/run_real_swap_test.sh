#!/bin/bash
# Foundry Real CLPool Swap 测试运行脚本

echo "========================================"
echo "CLPool Real Swap Foundry Fork 测试"
echo "========================================"

test -x "$(command -v forge)" >/dev/null 2>&1 || {
  echo "❌ forge 未安装"
  exit 1
}

if [ ! -f "test/CLPoolSwapReal.t.sol" ]; then
  echo "❌ test/CLPoolSwapReal.t.sol 未找到"
  exit 1
fi

RPC_URL=${BASE_RPC_URL:-"https://base.publicnode.com"}

echo "Using fork URL: $RPC_URL"

echo "请选择要运行的测试:"
echo "  1. testRealSwap_WETHToUSDC"
echo "  2. testRealSwap_USDCToWETH"
echo "  3. 运行全部测试"

echo ""
read -p "请输入选项 (1-3): " choice

echo ""
case "$choice" in
  1)
    forge test --match-test testRealSwap_WETHToUSDC -vvv --fork-url $RPC_URL
    ;;
  2)
    forge test --match-test testRealSwap_USDCToWETH -vvv --fork-url $RPC_URL
    ;;
  3)
    forge test --match-path test/CLPoolSwapReal.t.sol -vvv --fork-url $RPC_URL
    ;;
  *)
    echo "❌ 无效选项"
    exit 1
    ;;
esac

EXIT_CODE=$?
echo ""
echo "========================================"
if [ $EXIT_CODE -eq 0 ]; then
  echo "✅ 测试完成!"
else
  echo "❌ 测试失败 (退出码: $EXIT_CODE)"
fi
echo "========================================"
exit $EXIT_CODE
