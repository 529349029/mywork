/**
 * AAVE Reserves 数据获取并转换为 Markdown
 * 使用模块化管道系统，易于扩展
 */

const { createPipeline } = require('./pipeline');
const aaveModule = require('./modules/aaveModule');
const excelToMarkdownModule = require('./modules/excelToMarkdownModule');

// ==================== 配置区域 ====================
const CONFIG = {
  chainId: 56,  // 链 ID: 1=Ethereum, 56=BSC, 137=Polygon, etc.
  rpcUrl: 'https://bsc.publicnode.com',
  outputDir: __dirname
};

// ==================== 构建管道 ====================

async function main() {
  try {
    // 创建管道
    const pipeline = createPipeline('AAVE Reserves → Excel → Markdown')
      
      // 步骤1: 初始化 Web3 和合约
      .addStep('初始化 AAVE', aaveModule.initAAVE)
      
      // 步骤2: 获取 Reserves 列表
      .addStep('获取 Reserves 列表', aaveModule.fetchReservesList)
      
      // 步骤3: 批量获取 Reserve 数据
      .addStep('获取 Reserve 数据', aaveModule.fetchReserveData)
      
      // 步骤4: 批量获取代币信息
      .addStep('获取代币信息', aaveModule.fetchTokenInfo)
      
      // 步骤5: 批量获取 aToken 余额
      .addStep('获取 aToken 余额', aaveModule.fetchATokenBalances)
      
      // 步骤5.5: 批量获取债务代币供应量（新增）
      .addStep('获取债务代币供应量', aaveModule.fetchDebtTokenSupplies)
      
      // 步骤5.6: 批量获取利率策略参数（Optimal Utilization）
      .addStep('获取利率策略参数', aaveModule.fetchInterestRateStrategyParams)
      
      // 步骤6: 整合数据（包含使用率计算）
      .addStep('整合数据并计算使用率', aaveModule.mergeData)
      
      // 步骤7: 导出到 Excel
      .addStep('导出 Excel', aaveModule.exportToExcel)
      
      // 步骤8: 转换 Excel 为 Markdown
      .addStep('转换为 Markdown', excelToMarkdownModule.convertExcelToMarkdown);

    // 设置配置
    pipeline.setContext('chainId', CONFIG.chainId);
    pipeline.setContext('rpcUrl', CONFIG.rpcUrl);
    pipeline.setContext('outputDir', CONFIG.outputDir);

    // 执行管道
    await pipeline.execute();

  } catch (error) {
    console.error('\n❌ 管道执行失败:', error.message);
    process.exit(1);
  }
}

// 执行
main();
