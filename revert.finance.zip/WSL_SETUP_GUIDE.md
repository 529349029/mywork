# WSL 运行 Foundry Fork 测试指南

## 📋 前提条件检查

### 1. 确认 WSL 已安装

```bash
# 在 PowerShell 中运行
wsl --version
```

如果没有安装：
```powershell
wsl --install
```

**官方文档**: [WSL Installation Guide](https://learn.microsoft.com/en-us/windows/wsl/install)

---

### 2. 访问 Windows 文件

WSL 可以访问 Windows 文件系统，路径映射规则：
- Windows: `d:\usdt\wbnb\3\revert.finance`
- WSL: `/mnt/d/usdt/wbnb/3/revert.finance`

---

## 🚀 快速开始（3步）

### 步骤 1: 进入 WSL

```bash
# 从 Windows PowerShell 或 CMD
wsl

# 或者指定发行版
wsl -d Ubuntu
```

---

### 步骤 2: 导航到项目目录

```bash
cd /mnt/d/usdt/wbnb/3/revert.finance
```

**提示**: 可以设置别名简化操作
```bash
# 添加到 ~/.bashrc
echo 'alias cdrevert="cd /mnt/d/usdt/wbnb/3/revert.finance"' >> ~/.bashrc
source ~/.bashrc

# 以后直接运行
cdrevert
```

---

### 步骤 3: 安装 Foundry（如果还没装）

```bash
curl -L https://foundry.paradigm.xyz | bash
foundryup
```

验证安装：
```bash
forge --version
cast --version
```

**Foundry 官方文档**: [Getting Started](https://book.getfoundry.sh/getting-started/installation)

---

## 🎯 运行测试

### 方式 1: 使用交互式脚本（推荐）

```bash
# 赋予执行权限
chmod +x run_fork_test.sh

# 运行
./run_fork_test.sh
```

然后按提示选择测试场景。

---

### 方式 2: 直接运行 forge 命令

```bash
# 查看池子状态
forge test --match-test testInspectPool -vvv --fork-url https://mainnet.base.org

# 模拟小额交易
forge test --match-test testSmallSwap -vvv --fork-url https://mainnet.base.org

# 运行所有测试
forge test --match-path test/CLPoolSwap.t.sol -vvv --fork-url https://mainnet.base.org
```

---

### 方式 3: 使用环境变量配置 RPC

```bash
# 编辑 ~/.bashrc 或 ~/.zshrc
echo 'export BASE_RPC_URL="https://base.publicnode.com"' >> ~/.bashrc
source ~/.bashrc

# 然后运行（会自动使用配置的 RPC）
./run_fork_test.sh
```

---

## ⚙️ WSL 优化配置

### 1. 提高网络性能

WSL2 的网络有时较慢，可以优化：

**创建 `/etc/wsl.conf`**（在 WSL 中）：
```ini
[network]
generateResolvConf = false
```

**使用更快的 DNS**：
```bash
sudo rm /etc/resolv.conf
sudo echo "nameserver 8.8.8.8" > /etc/resolv.conf
sudo chattr +i /etc/resolv.conf  # 防止被覆盖
```

---

### 2. 增加文件监听限制

Foundry 可能需要大量文件句柄：

```bash
# 临时增加
ulimit -n 65536

# 永久增加（添加到 ~/.bashrc）
echo 'ulimit -n 65536' >> ~/.bashrc
```

---

### 3. 配置 Rust/Cargo 缓存

加速编译：

```bash
# 查看当前配置
cargo config get

# 设置并行编译任务数
echo '[build]' >> ~/.cargo/config.toml
echo 'jobs = 4' >> ~/.cargo/config.toml  # 根据你的 CPU 核心数调整
```

---

## 🔧 常见问题解决

### Q1: 找不到 forge 命令

**问题**: 
```bash
command not found: forge
```

**解决**:
```bash
# Foundry 安装在 ~/.foundry/bin
export PATH="$HOME/.foundry/bin:$PATH"

# 永久生效
echo 'export PATH="$HOME/.foundry/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

---

### Q2: RPC 连接超时

**问题**:
```
Error: failed to get fork block
```

**解决**: 更换 RPC
```bash
# 尝试其他 RPC
forge test --fork-url https://base.publicnode.com -vvv
forge test --fork-url https://base.llamarpc.com -vvv

# 或使用 Alchemy/Infura（需要 API Key）
forge test --fork-url https://base-mainnet.g.alchemy.com/v2/YOUR_API_KEY -vvv
```

**推荐的 Base RPC 列表**:
- `https://mainnet.base.org` (官方)
- `https://base.publicnode.com` (PublicNode)
- `https://base.llamarpc.com` (LlamaNodes)
- `https://1rpc.io/base` (1RPC)

---

### Q3: Gas 估算失败

**问题**:
```
Error: execution reverted
```

**解决**: 增加 gas limit
```bash
forge test --gas-limit 10000000 -vvv --fork-url https://mainnet.base.org
```

---

### Q4: 内存不足

**问题**: WSL 默认内存限制较低

**解决**: 在 Windows 中创建 `%USERPROFILE%\.wslconfig`

```ini
[wsl2]
memory=8GB
swap=4GB
localhostForwarding=true
```

然后重启 WSL：
```powershell
# 在 PowerShell 中
wsl --shutdown
wsl
```

---

### Q5: 文件权限问题

**问题**: 
```
Permission denied
```

**解决**:
```bash
# 赋予执行权限
chmod +x run_fork_test.sh

# 或者修复整个目录权限
chmod -R 755 /mnt/d/usdt/wbnb/3/revert.finance
```

---

## 💡 WSL 最佳实践

### 1. 使用 tmux 保持会话

```bash
# 安装 tmux
sudo apt install tmux

# 创建新会话
tmux new -s foundry

# 运行测试（即使断开连接也会继续）
./run_fork_test.sh

# 分离会话: Ctrl+B, D
# 重新连接: tmux attach -t foundry
```

**tmux 教程**: [tmux Cheat Sheet](https://tmuxcheatsheet.com/)

---

### 2. 使用 alias 简化命令

添加到 `~/.bashrc`：
```bash
# Foundry 快捷方式
alias ft='forge test'
alias fb='forge build'
alias fi='forge init'

# 项目快捷方式
alias cdrevert='cd /mnt/d/usdt/wbnb/3/revert.finance'
alias runtest='/mnt/d/usdt/wbnb/3/revert.finance/run_fork_test.sh'

# Fork 测试快捷方式
alias fork-small='forge test --match-test testSmallSwap -vvv --fork-url https://mainnet.base.org'
alias fork-medium='forge test --match-test testMediumSwap -vvv --fork-url https://mainnet.base.org'
alias fork-large='forge test --match-test testLargeSwap -vvv --fork-url https://mainnet.base.org'
```

然后：
```bash
source ~/.bashrc
cdrevert
fork-small
```

---

### 3. 日志输出到文件

```bash
# 保存测试结果
forge test -vvv --fork-url https://mainnet.base.org > test_results.log 2>&1

# 实时查看
tail -f test_results.log
```

---

### 4. 并行运行多个测试

```bash
# 使用 GNU Parallel
sudo apt install parallel

# 并行运行不同测试
parallel forge test --match-test {} -vvv --fork-url https://mainnet.base.org ::: \
    testSmallSwap \
    testMediumSwap \
    testLargeSwap
```

---

## 📊 性能对比

| 环境 | 速度 | 稳定性 | 推荐度 |
|------|------|--------|--------|
| **WSL2** | ⚡⚡⚡ 快 | ✅ 稳定 | ⭐⭐⭐⭐⭐ |
| Windows PowerShell | ⚡⚡ 中等 | ⚠️ 偶尔问题 | ⭐⭐⭐ |
| Docker | ⚡⚡⚡ 快 | ✅ 稳定 | ⭐⭐⭐⭐ |
| 原生 Linux | ⚡⚡⚡⚡ 最快 | ✅ 最稳定 | ⭐⭐⭐⭐⭐ |

---

## 🔗 相关资源

- **[WSL 官方文档](https://learn.microsoft.com/en-us/windows/wsl/)** - Microsoft 官方指南
- **[Foundry Book](https://book.getfoundry.sh/)** - Foundry 完整文档
- **[Base RPC Endpoints](https://docs.base.org/tools/network-information)** - Base 链 RPC 列表
- **[WSL2 Performance Tips](https://learn.microsoft.com/en-us/windows/wsl/tips-and-tricks)** - 性能优化技巧

---

## ✅ 快速检查清单

在运行测试前，确认：

- [ ] WSL 已安装并运行 (`wsl --status`)
- [ ] Foundry 已安装 (`forge --version`)
- [ ] 在项目目录 (`pwd` 应该显示 `/mnt/d/usdt/wbnb/3/revert.finance`)
- [ ] 测试文件存在 (`ls test/CLPoolSwap.t.sol`)
- [ ] 网络连接正常 (`ping base.org`)
- [ ] 有足够的内存（建议 4GB+）

---

## 🎉 开始测试！

```bash
# 1. 进入 WSL
wsl

# 2. 导航到项目
cd /mnt/d/usdt/wbnb/3/revert.finance

# 3. 运行测试
./run_fork_test.sh
```

祝你测试顺利！🚀
