require("@nomicfoundation/hardhat-toolbox");
require("@nomicfoundation/hardhat-verify");
require("@openzeppelin/hardhat-upgrades"); // 引入 OpenZeppelin Upgrades 插件
require("dotenv").config();
/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  // 1. Solidity 编译器配置
  solidity: {
    version: "0.8.28", // 对应你合约 pragma >=0.6.0 <0.7.0 的版本
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      },
      // 添加下面这部分配置
      outputSelection: {
        "*": {
          "*": ["storageLayout"],
        },
      },
    }
  },
  networks: {
    // ✅ 内置网络：不要加 url，Hardhat 会自动处理
    hardhat: {
      chainId: 31337,
      // 如果你想让 hardhat 网络模拟 BSC，可以加这个：
      // forking: { url: "https://bsc-dataseed.binance.org/" } 
    },

    // ✅ 本地节点：配合 npx hardhat node 使用，必须加 url
    localhost: {
      url: "http://127.0.0.1:8545"
    },
    fil: {
      url:"https://api.node.glif.io",
      chainId:314,
      accounts:[process.env.OWNER_PRIVATE_KEY,      // 对应 owner (索引 0)
      process.env.GNOSIS_ADMIN_PRIVATE_KEY, // 对应 gnosisAdmin (索引 1)
      process.env.OPERATOR_PRIVATE_KEY]   // 对应 operator (索引 2)]
    },
    // BSC 主网
    bsc:{
      //bsc-mainnet.infura.io
      url: "https://bsc.publicnode.com", // 📍 关键点：RPC 节点地址
      // url: "https://bsc-dataseed.binance.org/", // 📍 关键点：RPC 节点地址
      accounts: [
        process.env.OWNER_PRIVATE_KEY,      // 对应 owner (索引 0)
        process.env.GNOSIS_ADMIN_PRIVATE_KEY, // 对应 gnosisAdmin (索引 1)
        process.env.OPERATOR_PRIVATE_KEY   // 对应 operator (索引 2)
        //process.env.RECIPIENT_PRIVATE_KEY   // 对应 recipient (索引 3)
      ]       // 🔑 签名用的私钥
    },
    // BSC 测试网
    bsctest: {
      //前面的几个url都没用
      // url: "https://data-seed-prebsc-1-s1.binance.org:8545/",
      // url: "https://bsc-testnet-rpc.nodies.app", // 📍 关键点：RPC 节点地址
      // ✅ 尝试使用 Ankr 的公共节点（通常比官方稳定）
      url: "https://bsc-testnet.publicnode.com",
      chainId: 97,
      accounts: [
        process.env.OWNER_PRIVATE_KEY,      // 对应 owner (索引 0)
        process.env.GNOSIS_ADMIN_PRIVATE_KEY, // 对应 gnosisAdmin (索引 1)
        process.env.OPERATOR_PRIVATE_KEY
      ]
    },
    // Ethereum 主网
    ethereum: {
      url: "https://mainnet.infura.io/v3/YOUR_INFURA_KEY",
      chainId: 1,
      accounts: [process.env.OWNER_PRIVATE_KEY,
      process.env.GNOSIS_ADMIN_PRIVATE_KEY,
      process.env.OPERATOR_PRIVATE_KEY]
    },
    // Tron 主网 (EVM 兼容)
    tron: {
      url: "https://api.trongrid.io/jsonrpc",  // TronGrid RPC
      chainId: 728126428,  // Tron 主网 Chain ID
      accounts: [
        process.env.TRON_OWNER_PRIVATE_KEY,      // Owner
        process.env.TRON_GNOSIS_ADMIN_PRIVATE_KEY, // Gnosis Admin
        process.env.TRON_OPERATOR_PRIVATE_KEY    // Operator
      ],
      gasPrice: 420000000000, // 420 Gwei (Tron 默认)
      gas: 50000000           // 50M Gas limit
    },
    // Tron 测试网 (Shasta)
    trontest: {
      url: "https://api.shasta.trongrid.io/jsonrpc",  // Shasta Testnet RPC
      chainId: 2494104990,  // Shasta Chain ID
      accounts: [
        process.env.TRON_OWNER_PRIVATE_KEY,
        process.env.TRON_GNOSIS_ADMIN_PRIVATE_KEY,
        process.env.TRON_OPERATOR_PRIVATE_KEY
      ],
      gasPrice: 420000000000,
      gas: 50000000
    }
  },
  // 3. 路径配置（如果你的合约不在默认的 contracts/ 文件夹）
  paths: {
    sources: "./contracts", // Solidity 文件目录
    tests: "./test",        // 测试文件目录
    cache: "./cache",       // 缓存目录
    artifacts: "./artifacts" // 编译产物目录
  },   // ... 其他配置
  etherscan: {
    apiKey: {
      bscTestnet: "", // 如果没有可以留空，但验证可能会受限
      bsc: ""
    }
  },
  sourcify: {
    enabled: false
  }
};
