# Foundry Fork 模式模拟 CLPool Swap

## 🚀 快速开始

### 1. 安装 Foundry

```bash
curl -L https://foundry.paradigm.xyz | bash
foundryup
```

**官方文档**: [Foundry Book](https://book.getfoundry.sh/)

---

### 2. 初始化项目

```bash
cd d:\usdt\wbnb\3\revert.finance

# 如果还没有 foundry 项目
forge init --no-commit

# 安装 forge-std
forge install foundry-rs/forge-std
```

---

### 3. 运行测试

#### 方式 1: 使用默认 RPC

```bash
forge test --match-test testInspectPool -vvv
```

#### 方式 2: 指定 RPC URL

```bash
forge test --match-test testSmallSwap -vvv --fork-url https://mainnet.base.org
```

#### 方式 3: 使用 .env 文件

创建 `.env` 文件：
```env
BASE_RPC_URL=https://mainnet.base.org
```

然后运行：
```bash
source .env  # Linux/Mac
# 或
set -a; source .env; set +a  # Windows Git Bash

forge test --match-test testMediumSwap -vvv
```

---

## 📊 测试说明

### 可用的测试函数

| 测试函数 | 说明 | 命令 |
|---------|------|------|
| `testInspectPool` | 查看池子状态和价格 | `forge test --match-test testInspectPool -vvv` |
| `testSmallSwap` | 小额交易 (0.001 WETH) | `forge test --match-test testSmallSwap -vvv` |
| `testMediumSwap` | 中等交易 (0.01 WETH) | `forge test --match-test testMediumSwap -vvv` |
| `testLargeSwap` | 大额交易 (0.1 WETH) | `forge test --match-test testLargeSwap -vvv` |
| `testReverseSwap` | 反向交易 (USDC → WETH) | `forge test --match-test testReverseSwap -vvv` |
| `testExactOutputSwap` | 精确输出模式 | `forge test --match-test testExactOutputSwap -vvv` |

---

## 🔧 高级用法

### 1. 指定区块号 Fork

```bash
# 在特定区块号 fork，重现历史交易
forge test --fork-url https://mainnet.base.org --fork-block-number 15000000 -vvv
```

### 2. 增加 Verbosity

```bash
# -v: 基本信息
# -vv: 包含日志
# -vvv: 包含 traces
# -vvvv: 包含完整的 setup traces
# -vvvvv: 包含完整的 diff

forge test --match-test testSmallSwap -vvvv
```

### 3. Gas 报告

```bash
forge test --gas-report
```

### 4. 只运行某个文件

```bash
forge test --match-path test/CLPoolSwap.t.sol -vvv
```

---

## 💡 优势对比

### Foundry Fork vs JavaScript 模拟

| 特性 | Foundry Fork | JavaScript + Web3 |
|------|-------------|-------------------|
| **速度** | ⚡ 快（本地执行） | 🐌 慢（RPC 调用） |
| **可靠性** | ✅ 高（无速率限制） | ❌ 低（容易 rate limit） |
| **复杂度** | 🔧 需要 Solidity | 📝 JavaScript 更简单 |
| **调试** | 🔍 Traces 详细 | 📊 需要手动 logging |
| **Gas 估算** | ✅ 精确 | ⚠️ 估算可能不准 |
| **状态修改** | ✅ 可以 vm.store | ❌ 只能读 |
| **学习曲线** | 📈 较陡 | 📉 平缓 |

---

## 🎯 实际应用场景

### 场景 1: 测试套利策略

```solidity
function testArbitrage() public {
    // Fork 到某个区块
    vm.rollFork(15000000);
    
    // 检查两个 DEX 的价格差
    uint256 priceA = uniswapPool.getPrice();
    uint256 priceB = sushiswapPool.getPrice();
    
    if (priceA > priceB * 101 / 100) {
        // 执行套利
        // ...
    }
}
```

### 场景 2: 清算机器人测试

```solidity
function testLiquidation() public {
    // 找到健康因子 < 1 的借贷位置
    // 模拟清算并计算利润
    // ...
}
```

### 场景 3: MEV 策略回测

```solidity
function testMEVStrategy() public {
    // 遍历多个区块
    for (uint256 i = startBlock; i < endBlock; i++) {
        vm.rollFork(i);
        
        // 检查是否有可提取的 MEV
        // ...
    }
}
```

---

## ⚠️ 注意事项

### 1. RPC 选择

推荐使用稳定的 RPC：
- **Base 官方**: `https://mainnet.base.org`
- **PublicNode**: `https://base.publicnode.com`
- **LlamaNodes**: `https://base.llamarpc.com`
- **Alchemy/Infura**: 需要 API Key

### 2. 速率限制

如果遇到速率限制：
```bash
# 添加延迟
export FOUNDRY_FORK_RETRIES=5
export FOUNDRY_FORK_RETRY_BACKOFF=1000
```

### 3. 存储访问

使用 `vm.store` 时要小心：
```solidity
// 直接修改存储槽（仅用于测试！）
vm.store(tokenAddress, slot, newValue);
```

### 4. Cheatcodes 限制

某些操作在主网 fork 中不可用：
- ❌ `vm.warp` 不能改变真实历史时间
- ✅ `vm.roll` 可以改变区块号
- ✅ `vm.deal` 可以给地址发送 ETH

---

## 📚 相关资源

- **[Foundry 官方文档](https://book.getfoundry.sh/)** - 完整教程
- **[Foundry Cheatcodes](https://book.getfoundry.sh/cheatcodes/)** - 所有可用 cheatcodes
- **[Forge 参考](https://book.getfoundry.sh/reference/forge/forge-test)** - forge test 命令详解
- **[Base 链文档](https://docs.base.org/)** - Base 链信息
- **[Uniswap V3 Docs](https://docs.uniswap.org/contracts/v3/overview)** - Uniswap V3 技术文档

---

## 🐛 常见问题

### Q1: 提示 "failed to get fork block"

**解决**: 更换 RPC URL
```bash
forge test --fork-url https://base.publicnode.com -vvv
```

### Q2: Gas 估算失败

**解决**: 增加 gas limit
```bash
forge test --gas-limit 10000000 -vvv
```

### Q3: 测试太慢

**解决**: 减少 verbosity 或使用缓存
```bash
forge test -v  # 只用 -v 而不是 -vvv
```

### Q4: 如何保存 fork 状态？

Foundry fork 是临时的，每次测试都会重新 fork。如果需要持久化，考虑：
- 使用 Hardhat Network
- 搭建本地节点（Geth/Erigon）

---

## ✅ 总结

**Foundry Fork 模式的优势**：
1. ✅ 无需真实资金即可测试
2. ✅ 可以访问主网真实状态
3. ✅ 支持复杂的场景模拟
4. ✅ 速度快，无速率限制
5. ✅ 详细的 traces 帮助调试

**推荐工作流**：
1. 用 Foundry fork 开发和测试策略
2. 确认逻辑正确后
3. 在测试网验证
4. 最后上主网（小额开始）
