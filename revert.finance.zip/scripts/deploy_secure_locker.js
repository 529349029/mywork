const hre = require("hardhat");
const { ethers } = require("hardhat"); // ✅ 引入 ethers
const fs = require("fs");
const path = require("path");

// 创建日志流
const logStream = fs.createWriteStream(path.join(__dirname, "deployment_log.txt"), { flags: 'a' }); // 'a' 表示追加模式

// 备份原始的 console.log
const originalLog = console.log;

// 重写 console.log
console.log = function (...args) {
    const timestamp = new Date().toISOString();
    const message = `[${timestamp}] ${args.join(' ')}\n`;

    // 1. 写入文件
    logStream.write(message);

    // 2. 依然输出到屏幕
    originalLog.apply(console, args);
};

// ... 剩下的部署代码 ...
async function main() {
    // ✅ 检查当前连接的网络名称和 Chain ID
    const network = await ethers.provider.getNetwork();
    console.log("✅ 已连接到网络:", network.name, "Chain ID:", network.chainId);

    // ✅ 检查当前使用的钱包地址（来自 .env 里的私钥）
    const [signer] = await ethers.getSigners();
    console.log("✅ 当前钱包地址:", signer.address);
    // ==================== 1. 配置参数 ====================
    // 请替换为你实际的地址和配置
    const CONFIG = {
        admin: "0x94aF35A8dDE8ad2AFa22c159e88F088c006988F4",      // ✅ Admin: 多签钱包地址 (最高权限)
        owner: signer.address,          // Controller 的管理员（建议用多签或冷钱包），这里只用的热钱包
        operator: "0x6B3e753dC2A7bd530f7ee1f9832d102F837DF278",    // Withdrawer 的操作员（日常执行提现）

        withdrawalDelay: 24 * 60 * 60,     // 提现延时：24小时 (秒)

        // 初始限额设置 (单位: Wei)
        limits: {
            "0x55d398326f99059fF775485246999027B3197955": ethers.parseUnits("1000", 6), // USDT: 1万
            "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56": ethers.parseUnits("1000", 18), // BUSD: 1万
            "0x0000000000000000000000000000000000000000": ethers.parseEther("2"),       // BNB: 5个
        }
    };

    console.log("🚀 Starting Secure Locker Deployment...\n");
    console.log("Network:", hre.network.name);
    console.log("Gnosis WalletAdmin::", CONFIG.admin);
    console.log("Controller Owner::", CONFIG.owner);
    console.log("Withdrawer Operator::", CONFIG.operator);

    // ==================== 2. 部署 Vault ====================
    console.log("\n1️⃣  Deploying Vault...");
    const Vault = await ethers.getContractFactory("Vault");
    // 暂时授权给 Owner，稍后我们会转移给 Withdrawer 并撤销 Owner 权限
    const vault = await Vault.deploy(CONFIG.owner);
    // await vault.deployed();
    var vaultaddress = await vault.getAddress();
    console.log(`   ✅ Vault deployed to: ${vaultaddress}`);

    // ==================== 3. 部署 Controller ====================
    console.log("\n2️⃣  Deploying Controller...");
    const Controller = await ethers.getContractFactory("Controller");
    // 注意：此时 authorizedWithdrawer 填零地址或临时地址，稍后更新
    const controller = await Controller.deploy(
        vaultaddress,
        CONFIG.owner,
        CONFIG.withdrawalDelay,
        CONFIG.admin // 这里是多签地址，暂时用owner代替
    );
    // await controller.deployed();
    var controlleraddress = await controller.getAddress();
    console.log(`   ✅ Controller deployed to: ${controlleraddress}`);

    // ==================== 4. 部署 Withdrawer ====================
    console.log("\n3️⃣  Deploying Withdrawer...");
    const Withdrawer = await ethers.getContractFactory("Withdrawer");
    const withdrawer = await Withdrawer.deploy(
        vaultaddress,
        controlleraddress,
        CONFIG.operator
    );
    // await withdrawer.deployed();
    var withdraweraddress = await withdrawer.getAddress();
    console.log(`   ✅ Withdrawer deployed to: ${withdraweraddress}`);

    // ==================== 5. 关联与授权 (关键步骤) ====================
    console.log("\n4️⃣  Linking Contracts & Setting Permissions...");
    //将controller添加到Vault，这一步必须先做
    console.log("   - Updating vault with Controller address...");
    const tx0=await vault.setWithdrawerAuthorization(controlleraddress, true);
    await tx0.wait();
    // A. 在 Controller 中设置合法的 Withdrawer
    // console.log("   - Updating Controller with Withdrawer address...");
    //这里是多签测试的
    // const tx1 = await controller.updateWithdrawer(withdraweraddress);
    // await tx1.wait();

    // B. 在 Vault 中授权 Withdrawer
    console.log("   - Authorizing Withdrawer in Vault...");
    const tx2 = await vault.setWithdrawerAuthorization(withdraweraddress, true);
    await tx2.wait();

    // C. 【重要】撤销 Owner 在 Vault 中的直接权限
    // 这样确保了资金只能通过 Controller 的逻辑（带延时和限额）流出
    // if (CONFIG.owner !== vaultaddress) {
        console.log("   - Revoking Owner's direct access to Vault...");
        const tx3 = await vault.setWithdrawerAuthorization(CONFIG.owner, false);
        await tx3.wait();
    // }

    // ==================== 6. 初始化每日限额 ====================
    console.log("\n5️⃣  Setting Initial Daily Limits...");
    for (const [token, limit] of Object.entries(CONFIG.limits)) {
        console.log(`   - Setting limit for ${token}: ${limit}`);
        const tx = await controller.setTokenDailyLimit(token, limit);
        await tx.wait();
    }

    // ==================== 7. 总结 ====================
    console.log("\n🎉 Deployment Complete!");
    console.log("---------------------------------------------");
    console.log("Vault Address:      ", vaultaddress);
    console.log("Controller Address: ", controlleraddress);
    console.log("Withdrawer Address: ", withdraweraddress);
    console.log("---------------------------------------------");
    console.log("💡 Next Steps:");
    console.log("1. Transfer tokens to the Vault address.");
    console.log("2. Call 'lockToken' on Controller to start locking.");
    console.log("3. Verify contracts on BscScan/Etherscan.");
}

main()
    .then(() => {
        // 关闭日志流，确保所有日志都写入文件
        logStream.end(() => {
            process.exit(0);
        });
    })
    .catch((error) => {
        console.error(error);
        logStream.end(() => {
            process.exit(1);
        });
    });
//npx hardhat compile
//npx hardhat run scripts/deploy_secure_locker.js --network bsc
//npx hardhat run scripts/deploy_secure_locker.js --network bsctest | Tee-Object -FilePath deployment_log.txt