#!/bin/bash
# Foundry Fork 测试运行脚本 (Linux/WSL)

echo "========================================"
echo "CLPool Swap Foundry Fork 测试"
echo "========================================"
echo ""

# 检查 forge 是否安装
if ! command -v forge &> /dev/null; then
    echo "❌ 错误: 未找到 forge 命令"
    echo ""
    echo "请先安装 Foundry:"
    echo "curl -L https://foundry.paradigm.xyz | bash"
    echo "foundryup"
    echo ""
    exit 1
fi

echo "✅ Foundry 已安装"
forge --version
echo ""

# 检查是否在正确的目录
if [ ! -f "test/CLPoolSwap.t.sol" ]; then
    echo "❌ 错误: 未找到测试文件"
    echo "请确保在 d:/usdt/wbnb/3/revert.finance 目录下运行"
    echo "当前目录: $(pwd)"
    exit 1
fi

# 选择测试
echo "请选择要运行的测试:"
echo ""
echo "1. testInspectPool    - 查看池子状态"
echo "2. testSmallSwap      - 小额交易 (0.001 WETH)"
echo "3. testMediumSwap     - 中等交易 (0.01 WETH)"
echo "4. testLargeSwap      - 大额交易 (0.1 WETH)"
echo "5. testReverseSwap    - 反向交易 (USDC → WETH)"
echo "6. testExactOutput    - 精确输出模式"
echo "7. 运行所有测试"
echo ""
read -p "请输入选项 (1-7): " choice

echo ""
echo "🚀 开始执行..."
echo ""

# RPC URL（可以自定义）
RPC_URL=${BASE_RPC_URL:-"https://mainnet.base.org"}

case $choice in
    1)
        forge test --match-test testInspectPool -vvv --fork-url $RPC_URL
        ;;
    2)
        forge test --match-test testSmallSwap -vvv --fork-url $RPC_URL
        ;;
    3)
        forge test --match-test testMediumSwap -vvv --fork-url $RPC_URL
        ;;
    4)
        forge test --match-test testLargeSwap -vvv --fork-url $RPC_URL
        ;;
    5)
        forge test --match-test testReverseSwap -vvv --fork-url $RPC_URL
        ;;
    6)
        forge test --match-test testExactOutputSwap -vvv --fork-url $RPC_URL
        ;;
    7)
        forge test --match-path test/CLPoolSwap.t.sol -vvv --fork-url $RPC_URL
        ;;
    *)
        echo "❌ 无效选项"
        exit 1
        ;;
esac

EXIT_CODE=$?

echo ""
echo "========================================"
if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ 测试完成!"
else
    echo "❌ 测试失败 (退出码: $EXIT_CODE)"
fi
echo "========================================"

exit $EXIT_CODE
