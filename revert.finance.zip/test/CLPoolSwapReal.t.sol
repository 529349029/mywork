// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import "forge-std/Test.sol";

interface ICLPool {
    function slot0() external view returns (
        uint160 sqrtPriceX96,
        int24 tick,
        uint16 observationIndex,
        uint16 observationCardinality,
        uint16 observationCardinalityNext,
        bool unlocked
    );

    function token0() external view returns (address);
    function token1() external view returns (address);
    function liquidity() external view returns (uint128);
    function fee() external view returns (uint24);

    function swap(
        address recipient,
        bool zeroForOne,
        int256 amountSpecified,
        uint160 sqrtPriceLimitX96,
        bytes calldata data
    ) external returns (int256 amount0, int256 amount1);
}

interface ICLSwapCallback {
    function uniswapV3SwapCallback(
        int256 amount0Delta,
        int256 amount1Delta,
        bytes calldata data
    ) external;
}

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
}

interface IWETH {
    function deposit() external payable;
    function withdraw(uint256 amount) external;
}

contract CLPoolSwapRealTest is Test, ICLSwapCallback {
    address constant POOL_ADDRESS = 0xb2cc224c1c9feE385f8ad6a55b4d94E92359DC59;
    address constant WETH = 0x4200000000000000000000000000000000000006;
    address constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;

    ICLPool pool;
    IERC20 weth;
    IERC20 usdc;

    function setUp() public {
        vm.createSelectFork(vm.envOr("BASE_RPC_URL", string("https://base.publicnode.com")));

        pool = ICLPool(POOL_ADDRESS);
        weth = IERC20(WETH);
        usdc = IERC20(USDC);
    }

    receive() external payable {}

    function testRealSwap_WETHToUSDC() public {
        uint256 amountIn = 0.01 ether;
        _fundWETH(amountIn);

        (uint160 sqrtPriceX96, , , , , ) = pool.slot0();
        uint160 sqrtPriceLimitX96 = _calculatePriceLimit(sqrtPriceX96, true, 3);

        uint256 usdcBefore = usdc.balanceOf(address(this));

        (int256 amount0, int256 amount1) = pool.swap(
            address(this),
            true,
            int256(amountIn),
            sqrtPriceLimitX96,
            ""
        );

        assertEq(amount0, int256(amountIn));
        assertLt(amount1, 0);
        assertGt(usdc.balanceOf(address(this)), usdcBefore);
    }

    function testRealSwap_USDCToWETH() public {
        uint256 amountIn = 200 * 1e6;
        _fundUSDC(address(this), amountIn);

        (uint160 sqrtPriceX96, , , , , ) = pool.slot0();
        uint160 sqrtPriceLimitX96 = _calculatePriceLimit(sqrtPriceX96, false, 3);

        uint256 wethBefore = weth.balanceOf(address(this));

        (int256 amount0, int256 amount1) = pool.swap(
            address(this),
            false,
            int256(amountIn),
            sqrtPriceLimitX96,
            ""
        );

        assertEq(amount1, int256(amountIn));
        assertLt(amount0, 0);
        assertGt(weth.balanceOf(address(this)), wethBefore);
    }

    function uniswapV3SwapCallback(
        int256 amount0Delta,
        int256 amount1Delta,
        bytes calldata
    ) external override {
        require(msg.sender == POOL_ADDRESS, "Callback only from pool");

        if (amount0Delta > 0) {
            require(weth.transfer(msg.sender, uint256(amount0Delta)), "WETH transfer failed");
        }
        if (amount1Delta > 0) {
            require(usdc.transfer(msg.sender, uint256(amount1Delta)), "USDC transfer failed");
        }
    }

    function _fundWETH(uint256 amount) internal {
        vm.deal(address(this), amount);
        IWETH(WETH).deposit{value: amount}();
    }

    function _fundUSDC(address who, uint256 amount) internal {
        for (uint256 slot = 0; slot < 16; slot++) {
            vm.store(USDC, keccak256(abi.encode(who, slot)), bytes32(amount));
        }
    }

    function _calculatePriceLimit(
        uint160 currentSqrtPrice,
        bool zeroForOne,
        uint256 slippagePercent
    ) internal pure returns (uint160) {
        if (zeroForOne) {
            return uint160(uint256(currentSqrtPrice) * (100 - slippagePercent) / 100);
        } else {
            return uint160(uint256(currentSqrtPrice) * (100 + slippagePercent) / 100);
        }
    }
}
