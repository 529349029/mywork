#!/bin/bash
# SecureLocker 金库系统 Forge 测试脚本
# 适用于 BSC 主网部署的金库系统

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "========================================"
echo "SecureLocker 金库系统测试套件"
echo "========================================"
echo ""

# 检查 forge 是否安装
if ! command -v forge &> /dev/null; then
    echo -e "${RED}❌ forge 未安装${NC}"
    echo "请运行: curl -L https://foundry.paradigm.xyz | bash"
    exit 1
fi

echo -e "${GREEN}✓ forge 已安装${NC}"
echo ""

# 检查测试文件是否存在
if [ ! -f "test/SecureLockerSystem.t.sol" ]; then
    echo -e "${RED}❌ 测试文件不存在: test/SecureLockerSystem.t.sol${NC}"
    exit 1
fi

echo -e "${GREEN}✓ 测试文件存在${NC}"
echo ""

# 编译合约
echo "----------------------------------------"
echo "1️⃣  编译合约..."
echo "----------------------------------------"
forge build
echo ""

# 运行测试选项
show_menu() {
    echo "请选择测试选项:"
    echo ""
    echo "  1) 运行所有测试 (完整测试套件)"
    echo "  2) 运行 Vault 测试"
    echo "  3) 运行 Controller 测试"
    echo "  4) 运行 Withdrawer 测试"
    echo "  5) 运行安全测试"
    echo "  6) 运行完整流程测试"
    echo "  7) 运行边界测试"
    echo "  8) 运行集成测试"
    echo "  9) 运行单笔交易测试 (verbose)"
    echo "  10) 生成测试覆盖率报告"
    echo "  11) Fork BSC 主网测试 (需要 RPC URL)"
    echo ""
    echo "  0) 退出"
    echo ""
}

run_tests() {
    case $1 in
        1)
            echo -e "${BLUE}运行完整测试套件...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol -vv
            ;;
        2)
            echo -e "${BLUE}运行 Vault 测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Vault" -vv
            ;;
        3)
            echo -e "${BLUE}运行 Controller 测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Controller" -vv
            ;;
        4)
            echo -e "${BLUE}运行 Withdrawer 测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Withdrawer" -vv
            ;;
        5)
            echo -e "${BLUE}运行安全测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Security" -vv
            ;;
        6)
            echo -e "${BLUE}运行完整流程测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_FullFlow" -vv
            ;;
        7)
            echo -e "${BLUE}运行边界测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_EdgeCase" -vv
            ;;
        8)
            echo -e "${BLUE}运行集成测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Integration" -vv
            ;;
        9)
            echo -e "${BLUE}运行详细单笔测试...${NC}"
            forge test --match-path test/SecureLockerSystem.t.sol --match-test "test_Vault_InitialSetup" -vvvv
            ;;
        10)
            echo -e "${BLUE}生成测试覆盖率报告...${NC}"
            forge coverage --match-path test/SecureLockerSystem.t.sol --report lcov
            echo "覆盖率报告已生成在 lcov.info"
            ;;
        11)
            echo -e "${BLUE}Fork BSC 主网测试${NC}"
            echo "请设置 BSC_RPC_URL 环境变量"
            echo "示例: BSC_RPC_URL=https://bsc.publicnode.com"
            if [ -z "$BSC_RPC_URL" ]; then
                echo -e "${YELLOW}使用默认 RPC...${NC}"
                BSC_RPC_URL="https://bsc.publicnode.com"
            fi
            echo "RPC: $BSC_RPC_URL"
            # 注意: Fork 测试需要使用真实代币地址
            # forge test --match-path test/SecureLockerSystem.t.sol -vv --fork-url $BSC_RPC_URL
            echo "注意: Fork 模式需要配置真实代币地址，请手动运行"
            ;;
        0)
            echo "退出"
            exit 0
            ;;
        *)
            echo -e "${RED}无效选项${NC}"
            exit 1
            ;;
    esac
}

# 如果有参数，直接执行
if [ $# -gt 0 ]; then
    run_tests "$1"
    exit $?
fi

# 显示菜单并等待输入
while true; do
    show_menu
    read -p "请输入选项 (0-11): " choice
    echo ""
    run_tests "$choice"
    EXIT_CODE=$?
    echo ""
    echo "========================================"
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}✅ 测试完成!${NC}"
    else
        echo -e "${RED}❌ 测试失败 (退出码: $EXIT_CODE)${NC}"
    fi
    echo "========================================"
    echo ""
done
