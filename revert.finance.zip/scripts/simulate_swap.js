/**
 * 模拟 Uniswap V3 风格的 CLPool swap 交易
 * 
 * 这个脚本演示如何调用 Revert Finance 的 CLPool 合约进行实际交换
 */

const { Web3 } = require('web3');

// ==================== 配置 ====================
const RPC_URL = 'https://mainnet.base.org'; // Base 链 RPC
const POOL_ADDRESS = '0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59'; // CLPool 合约地址

// Pool ABI（只需要 swap 函数）
const POOL_ABI = [
    {
        "inputs": [
            { "internalType": "address", "name": "recipient", "type": "address" },
            { "internalType": "bool", "name": "zeroForOne", "type": "bool" },
            { "internalType": "int256", "name": "amountSpecified", "type": "int256" },
            { "internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160" },
            { "internalType": "bytes", "name": "data", "type": "bytes" }
        ],
        "name": "swap",
        "outputs": [
            { "internalType": "int256", "name": "amount0", "type": "int256" },
            { "internalType": "int256", "name": "amount1", "type": "int256" }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "slot0",
        "outputs": [
            { "internalType": "uint160", "name": "sqrtPriceX96", "type": "uint160" },
            { "internalType": "int24", "name": "tick", "type": "int24" },
            { "internalType": "uint16", "name": "observationIndex", "type": "uint16" },
            { "internalType": "uint16", "name": "observationCardinality", "type": "uint16" },
            { "internalType": "uint16", "name": "observationCardinalityNext", "type": "uint16" },
            { "internalType": "bool", "name": "unlocked", "type": "bool" }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token0",
        "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token1",
        "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
        "stateMutability": "view",
        "type": "function"
    }
];

// ERC20 ABI（用于授权和查询余额）
const ERC20_ABI = [
    {
        "inputs": [{ "internalType": "address", "name": "account", "type": "address" }],
        "name": "balanceOf",
        "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "address", "name": "spender", "type": "address" },
            { "internalType": "uint256", "name": "amount", "type": "uint256" }
        ],
        "name": "approve",
        "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "decimals",
        "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "symbol",
        "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
        "stateMutability": "view",
        "type": "function"
    }
];

// ==================== 辅助函数 ====================

/**
 * 计算价格限制的平方根（简化版）
 * 实际应该使用 TickMath.getSqrtRatioAtTick
 */
function calculatePriceLimit(currentSqrtPrice, slippagePercent = 5) {
    // 允许 5% 的滑点
    const slippageFactor = (100 - slippagePercent) / 100;
    return BigInt(Math.floor(Number(currentSqrtPrice) * slippageFactor));
}

/**
 * 格式化大数为可读格式
 */
function formatAmount(amount, decimals = 18) {
    return (Number(amount) / Math.pow(10, decimals)).toFixed(6);
}

// ==================== 主函数 ====================

async function simulateSwap() {
    console.log('🚀 开始模拟 CLPool Swap 交易\n');
    
    // 1. 初始化 Web3
    const web3 = new Web3(RPC_URL);
    const poolContract = new web3.eth.Contract(POOL_ABI, POOL_ADDRESS);
    
    // 2. 获取池子信息
    console.log('📊 步骤 1: 获取池子基本信息...');
    const [token0Addr, token1Addr, slot0] = await Promise.all([
        poolContract.methods.token0().call(),
        poolContract.methods.token1().call(),
        poolContract.methods.slot0().call()
    ]);
    
    console.log(`   Token0: ${token0Addr}`);
    console.log(`   Token1: ${token1Addr}`);
    console.log(`   当前价格 (sqrtPriceX96): ${slot0.sqrtPriceX96}`);
    console.log(`   当前 Tick: ${slot0.tick}`);
    console.log(`   池子状态: ${slot0.unlocked ? '✅  unlocked' : '❌ locked'}`);
    
    // 3. 获取代币信息
    console.log('\n📊 步骤 2: 获取代币详情...');
    const token0Contract = new web3.eth.Contract(ERC20_ABI, token0Addr);
    const token1Contract = new web3.eth.Contract(ERC20_ABI, token1Addr);
    
    const [token0Symbol, token1Symbol, token0Decimals, token1Decimals] = await Promise.all([
        token0Contract.methods.symbol().call(),
        token1Contract.methods.symbol().call(),
        token0Contract.methods.decimals().call(),
        token1Contract.methods.decimals().call()
    ]);
    
    console.log(`   Token0: ${token0Symbol} (${token0Decimals} decimals)`);
    console.log(`   Token1: ${token1Symbol} (${token1Decimals} decimals)`);
    
    // 4. 设置交易参数
    console.log('\n⚙️  步骤 3: 配置交易参数...');
    
    // ⚠️ 注意：这里需要替换为你的实际钱包地址
    const YOUR_WALLET = '0xYourWalletAddressHere'; // ← 修改这里
    const RECIPIENT = YOUR_WALLET; // 接收地址
    
    // 交易方向：Token0 → Token1
    const ZERO_FOR_ONE = true;
    
    // 交换数量：卖出 0.01 个 Token0（需要根据实际 decimals 调整）
    const AMOUNT_TO_SELL = web3.utils.toWei('0.01', 'ether'); // 假设 18 decimals
    const AMOUNT_SPECIFIED = ZERO_FOR_ONE ? AMOUNT_TO_SELL : -AMOUNT_TO_SELL;
    
    // 价格限制：允许 5% 滑点
    const currentSqrtPrice = BigInt(slot0.sqrtPriceX96);
    const sqrtPriceLimit = ZERO_FOR_ONE 
        ? calculatePriceLimit(currentSqrtPrice, 5)  // zeroForOne 时价格下降
        : calculatePriceLimit(currentSqrtPrice, -5); // oneForZero 时价格上升
    
    console.log(`   交易方向: ${ZERO_FOR_ONE ? `${token0Symbol} → ${token1Symbol}` : `${token1Symbol} → ${token0Symbol}`}`);
    console.log(`   卖出数量: ${formatAmount(AMOUNT_TO_SELL, token0Decimals)} ${token0Symbol}`);
    console.log(`   amountSpecified: ${AMOUNT_SPECIFIED}`);
    console.log(`   价格限制 (sqrtPriceLimitX96): ${sqrtPriceLimit}`);
    console.log(`   接收地址: ${RECIPIENT}`);
    
    // 5. 检查余额和授权
    console.log('\n🔍 步骤 4: 检查余额和授权...');
    const balanceBefore = await token0Contract.methods.balanceOf(YOUR_WALLET).call();
    console.log(`   当前 ${token0Symbol} 余额: ${formatAmount(balanceBefore, token0Decimals)}`);
    
    if (BigInt(balanceBefore) < BigInt(AMOUNT_TO_SELL)) {
        console.error(`   ❌ 余额不足！需要 ${formatAmount(AMOUNT_TO_SELL, token0Decimals)}，但只有 ${formatAmount(balanceBefore, token0Decimals)}`);
        console.log('\n💡 提示：请先向钱包充值或使用测试网代币');
        return;
    }
    
    // 检查是否已授权
    const allowance = await token0Contract.methods.allowance(YOUR_WALLET, POOL_ADDRESS).call();
    console.log(`   当前授权额度: ${formatAmount(allowance, token0Decimals)}`);
    
    if (BigInt(allowance) < BigInt(AMOUNT_TO_SELL)) {
        console.log(`   ⚠️  需要先授权 Pool 合约使用 ${token0Symbol}`);
        console.log(`   执行授权交易...`);
        
        // 这里需要私钥签名，实际使用时取消注释
        /*
        const account = web3.eth.accounts.privateKeyToAccount('YOUR_PRIVATE_KEY');
        web3.eth.accounts.wallet.add(account);
        
        const approveTx = await token0Contract.methods.approve(POOL_ADDRESS, AMOUNT_TO_SELL).send({
            from: YOUR_WALLET,
            gas: 100000
        });
        console.log(`   ✅ 授权成功! TX: ${approveTx.transactionHash}`);
        */
        
        console.log('   ⏸️  授权功能已注释，请手动授权后继续');
        return;
    }
    
    // 6. 构建回调数据
    console.log('\n📦 步骤 5: 准备回调数据...');
    // CLPool 需要实现 ICLSwapCallback 接口
    // 如果是通过 Router 调用，Router 会处理 callback
    // 直接调用需要提供正确的 data
    const CALLBACK_DATA = '0x'; // 简化示例，实际需要编码回调参数
    
    // 7. 估算 Gas
    console.log('\n⛽ 步骤 6: 估算 Gas...');
    try {
        const gasEstimate = await poolContract.methods.swap(
            RECIPIENT,
            ZERO_FOR_ONE,
            AMOUNT_SPECIFIED.toString(),
            sqrtPriceLimit.toString(),
            CALLBACK_DATA
        ).estimateGas({
            from: YOUR_WALLET
        });
        
        console.log(`   预估 Gas: ${gasEstimate}`);
        console.log(`   Base Fee: ~0.001 Gwei (Base 链)`);
        console.log(`   预估 Gas 费用: ~${(gasEstimate * 0.001 / 1e9).toFixed(6)} ETH`);
    } catch (error) {
        console.error(`   ❌ Gas 估算失败: ${error.message}`);
        console.log('   可能原因：');
        console.log('   - 余额不足');
        console.log('   - 未授权');
        console.log('   - 价格超出限制');
        return;
    }
    
    // 8. 执行交易（模拟）
    console.log('\n💸 步骤 7: 执行交易...');
    console.log('   ⚠️  以下为模拟执行，不会真正发送交易\n');
    
    console.log('   📋 交易参数汇总:');
    console.log('   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`   Pool 地址:     ${POOL_ADDRESS}`);
    console.log(`   调用函数:      swap()`);
    console.log(`   recipient:     ${RECIPIENT}`);
    console.log(`   zeroForOne:    ${ZERO_FOR_ONE}`);
    console.log(`   amountSpec:    ${AMOUNT_SPECIFIED}`);
    console.log(`   priceLimit:    ${sqrtPriceLimit}`);
    console.log(`   data:          ${CALLBACK_DATA}`);
    console.log('   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    console.log('   🔧 如果要真正执行，需要：');
    console.log('   1. 导入私钥: web3.eth.accounts.privateKeyToAccount(PRIVATE_KEY)');
    console.log('   2. 发送交易:');
    console.log('      const tx = await poolContract.methods.swap(...).send({');
    console.log('          from: YOUR_WALLET,');
    console.log('          gas: gasEstimate');
    console.log('      });');
    console.log('   3. 等待确认并检查结果\n');
    
    // 9. 预期结果说明
    console.log('📈 预期结果:');
    console.log('   - amount0: 正数表示你支付的 Token0 数量');
    console.log('   - amount1: 负数表示你收到的 Token1 数量（取绝对值）');
    console.log('   - 实际交换比例取决于池子的流动性和当前价格\n');
    
    console.log('✅ 模拟完成！');
    console.log('\n💡 下一步建议:');
    console.log('   1. 在 BaseScan 查看 Pool 的实际交易:');
    console.log(`      https://basescan.org/address/${POOL_ADDRESS}#transactions`);
    console.log('   2. 使用 Revert Finance UI 进行实际交易:');
    console.log('      https://revert.finance/');
    console.log('   3. 参考官方文档了解 Callback 机制:');
    console.log('      https://docs.uniswap.org/contracts/v3/reference/core/interfaces/callback/IUniswapV3SwapCallback');
}

// ==================== 运行 ====================

simulateSwap().catch(error => {
    console.error('\n❌ 错误:', error.message);
    console.error('\n堆栈跟踪:');
    console.error(error.stack);
});
