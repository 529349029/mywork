// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import "forge-std/Test.sol";

interface ICLPool {
    function slot0() external view returns (
        uint160 sqrtPriceX96,
        int24 tick,
        uint16 observationIndex,
        uint16 observationCardinality,
        uint16 observationCardinalityNext,
        bool unlocked
    );
    
    function token0() external view returns (address);
    function token1() external view returns (address);
    function liquidity() external view returns (uint128);
    function fee() external view returns (uint24);
    
    function swap(
        address recipient,
        bool zeroForOne,
        int256 amountSpecified,
        uint160 sqrtPriceLimitX96,
        bytes calldata data
    ) external returns (int256 amount0, int256 amount1);
}

interface IERC20 {
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function decimals() external view returns (uint8);
    function symbol() external view returns (string memory);
}

interface IWETH {
    function deposit() external payable;
    function withdraw(uint256 amount) external;
}

/**
 * @title CLPool Swap Simulation Test
 * @dev Simulates trades on Base Mainnet using Foundry fork mode
 */
contract CLPoolSwapTest is Test {
    // ==================== Contract Addresses ====================
    
    // Revert Finance CLPool
    address constant POOL_ADDRESS = 0xb2cc224c1c9feE385f8ad6a55b4d94E92359DC59;
    
    // Token Addresses
    address constant WETH = 0x4200000000000000000000000000000000000006;
    address constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    
    // ==================== State Variables ====================
    
    ICLPool pool;
    IERC20 weth;
    IERC20 usdc;
    
    // Test trader address
    address trader;
    uint256 traderPrivateKey;
    
    // ==================== Setup ====================
    
    function setUp() public {
        // Fork Base Mainnet
        vm.createSelectFork(vm.envOr("BASE_RPC_URL", string("https://base.publicnode.com")));

        // Initialize contract instances
        pool = ICLPool(POOL_ADDRESS);
        weth = IERC20(WETH);
        usdc = IERC20(USDC);
        
        // Create test trader
        (trader, traderPrivateKey) = makeAddrAndKey("trader");
        
        // Give trader some ETH for Gas
        vm.deal(trader, 1 ether);
        
        console.log("========================================");
        console.log(unicode"CLPool Swap 模拟测试初始化完成"); // Fixed: Added unicode prefix
        console.log("========================================");
        console.log("");
    }
    
    // ==================== Test 1: Inspect Pool State ====================
    
    function testInspectPool() public view {
        console.log(unicode"📊 步骤 1: 检查池子状态\n"); // Fixed
        
        (
            uint160 sqrtPriceX96,
            int24 tick,
            ,
            ,
            ,
            bool unlocked
        ) = pool.slot0();
        
        address token0 = pool.token0();
        address token1 = pool.token1();
        uint128 liquidity = pool.liquidity();
        uint24 fee = pool.fee();
        
        console.log("Pool Address:", POOL_ADDRESS);
        console.log("Token0:", token0);
        console.log("Token1:", token1);
        console.log("Current Tick:", tick);
        console.log("Liquidity:", liquidity);
        console.log("Fee:", fee, "basis points");
        console.log("Pool Status:", unlocked ? "Unlocked" : "Locked");
        console.log("");
        
        // Calculate current price
        uint256 price = _getPriceFromSqrtPriceX96(sqrtPriceX96);
        console.log("Current Price:",price);
        console.log(unicode"当前价格: 1 WETH =");
        console.log(price / 1e6);
        console.log("");
    }
    
    // ==================== Test 2: Small Swap Simulation ====================
    
    function testSmallSwap() public {
        console.log(unicode"💰 步骤 2: 模拟小额交易 (0.001 WETH → USDC)\n"); // Fixed
        
        uint256 amountIn = 0.001 ether; // 0.001 WETH
        
        // Give trader WETH
        _giveWETH(trader, amountIn);
        
        console.log("Trader WETH balance:");
        console.log(weth.balanceOf(trader) / 1e15);
        console.log("Trader USDC balance:");
        console.log(usdc.balanceOf(trader) / 1e6);
        console.log("");
        
        // Execute swap
        (int256 amount0, int256 amount1) = _executeSwap(trader, true, int256(amountIn), 5); // 5% slippage
        
        console.log(unicode"✅ 交易完成!");
        console.log("amount0 (WETH change):");
        console.log(amount0 / 1e15);
        console.log("amount1 (USDC change):");
        console.log(amount1 < 0 ? -amount1 : amount1);
        console.log("");
        
        console.log("Post-swap balances:");
        console.log("WETH:");
        console.log(weth.balanceOf(trader) / 1e15);
        console.log("USDC:");
        console.log(usdc.balanceOf(trader) / 1e6);
        console.log("");
        
        // Verify simulated swap results
        assertEq(uint256(amount0), amountIn, "Expected WETH amount to match input");
        assertLt(amount1, 0, "Expected USDC output to be negative");
    }
    
    // ==================== Test 3: Medium Swap Simulation ====================
    
    function testMediumSwap() public {
        console.log(unicode"💰 步骤 3: 模拟中等交易 (0.01 WETH → USDC)\n"); // Fixed
        
        uint256 amountIn = 0.01 ether;
        
        _giveWETH(trader, amountIn);
        
        console.log("Before trade:");
        console.log("WETH:");
        console.log(weth.balanceOf(trader) / 1e16);
        console.log("USDC:");
        console.log(usdc.balanceOf(trader) / 1e6);
        console.log("");
        
        (int256 amount0, int256 amount1) = _executeSwap(trader, true, int256(amountIn), 3); // 3% slippage
        
        console.log(unicode"✅ 交易完成!");
        console.log(unicode"实际支付 WETH:");
        console.log(amount0 / 1e16);
        console.log(unicode"实际收到 USDC:");
        console.log((-amount1) / 1e6);
        console.log("");
        
        // Calculate effective exchange rate
        if (amount0 > 0 && amount1 < 0) {
            uint256 effectivePrice = (uint256(-amount1) * 1e18) / uint256(amount0);
            console.log("Effective price (1 WETH):");
            console.log(effectivePrice / 1e6);
        }
        console.log("");
    }
    
    // ==================== Test 4: Large Swap Simulation ====================
    
    function testLargeSwap() public {
        console.log(unicode"💰 步骤 4: 模拟大额交易 (0.1 WETH → USDC)\n"); // Fixed
        
        uint256 amountIn = 0.1 ether;
        
        _giveWETH(trader, amountIn);
        
        console.log(unicode"交易金额: 0.1 WETH"); // Fixed
        console.log("");
        
        // Large swaps need higher slippage tolerance
        (int256 amount0, int256 amount1) = _executeSwap(trader, true, int256(amountIn), 10); // 10% slippage
        
        console.log(unicode"✅ 交易完成!");
        console.log("Paid WETH:");
        console.log(amount0 / 1e17);
        console.log("Received USDC:");
        console.log((-amount1) / 1e6);
        console.log("");
        
        // Check price impact
        (uint160 sqrtPriceAfter, , , , , ) = pool.slot0();
        console.log("Post-swap sqrtPriceX96:");
        console.log(sqrtPriceAfter);
        console.log("");
    }
    
    // ==================== Test 5: Reverse Swap (USDC → WETH) ====================
    
    function testReverseSwap() public {
        console.log(unicode"💰 步骤 5: 模拟反向交易 (100 USDC → WETH)\n"); // Fixed
        
        uint256 amountIn = 100 * 1e6; // 100 USDC
        
        // Give trader USDC
        _giveUSDC(trader, amountIn);
        
        console.log("Before trade:");
        console.log("USDC:");
        console.log(usdc.balanceOf(trader) / 1e6);
        console.log("WETH:");
        console.log(weth.balanceOf(trader) / 1e18);
        console.log("");
        
        // zeroForOne = false (USDC → WETH)
        (int256 amount0, int256 amount1) = _executeSwap(trader, false, int256(amountIn), 5);
        
        console.log(unicode"✅ 交易完成!");
        console.log("amount0 (WETH change):");
        console.log(amount0 < 0 ? -amount0 : amount0);
        console.log("amount1 (USDC change):");
        console.log(amount1);
        console.log("");
        
        console.log("Post-swap balances:");
        console.log("USDC:");
        console.log(usdc.balanceOf(trader) / 1e6);
        console.log("WETH:");
        console.log(weth.balanceOf(trader) / 1e18);
        console.log("");
    }
    
    // ==================== Test 6: Exact Output Mode ====================
    
    function testExactOutputSwap() public {
        console.log(unicode"💰 步骤 6: 模拟精确输出 (想要 50 USDC)\n"); // Fixed
        
        // amountSpecified negative means exact output
        int256 amountOutDesired = -int256(50 * 1e6); // Want 50 USDC
        
        // Give enough WETH first
        _giveWETH(trader, 0.1 ether);
        
        console.log(unicode"目标: receive 50 USDC");
        console.log("");
        
        (int256 amount0, int256 amount1) = _executeSwap(trader, true, amountOutDesired, 10);
        
        console.log(unicode"✅ 交易完成!"); // Fixed
        console.log("Actual paid WETH:");
        console.log(amount0 / 1e18);
        console.log("Actual received USDC:");
        console.log((-amount1) / 1e6);
        console.log("");
        
        // Verify received USDC is close to target
        assertApproxEqAbs(uint256(-amount1), 50 * 1e6, 1e6, "USDC should be within expected range");
    }
    
    // ==================== Internal Functions ====================
    
    /**
     * Execute swap transaction
     */
    function _executeSwap(
        address who,
        bool zeroForOne,
        int256 amountSpecified,
        uint256 slippagePercent
    ) internal returns (int256 amount0, int256 amount1) {
        // Get current price
        (uint160 sqrtPriceX96, , , , , ) = pool.slot0();
        
        // Calculate price limit
        uint160 sqrtPriceLimitX96 = _calculatePriceLimit(sqrtPriceX96, zeroForOne, slippagePercent);
        
        console.log(unicode"交易参数:"); // Fixed
        console.log("  zeroForOne:", zeroForOne);
        console.log("  amountSpecified:", amountSpecified);
        console.log("  sqrtPriceLimitX96:", sqrtPriceLimitX96);
        console.log("");
        
        // Simulate trader calling swap
        vm.startPrank(who);
        
        // Note: Directly calling Pool requires implementing callback
        // Here we simplify, assuming usage via Router or callback-supporting contract
        
        // Since direct Pool call requires complex callback implementation
        // We use estimation to show expected results
        
        console.log(unicode"⚠️  注意: 直接调用 Pool 需要实现 ICLSwapCallback"); // Fixed
        console.log(unicode"   实际使用时应通过 Uniswap V3 Router\n"); // Fixed
        
        // Here we only check balances and validate parameters
        if (zeroForOne) {
            uint256 wethBalance = weth.balanceOf(who);
            uint256 requiredWETH = amountSpecified > 0 ? uint256(amountSpecified) : uint256(-amountSpecified) * 2; // Estimate
            console.log(unicode"需要 WETH:");
            console.log(requiredWETH / 1e18);
            console.log(unicode"当前 WETH 余额:");
            console.log(wethBalance / 1e18);
            require(wethBalance >= requiredWETH, "Insufficient WETH balance");
        } else {
            uint256 usdcBalance = usdc.balanceOf(who);
            uint256 requiredUSDC = amountSpecified > 0 ? uint256(amountSpecified) : uint256(-amountSpecified);
            console.log(unicode"需要 USDC:");
            console.log(requiredUSDC / 1e6);
            console.log(unicode"当前 USDC 余额:");
            console.log(usdcBalance / 1e6);
            require(usdcBalance >= requiredUSDC, "Insufficient USDC balance");
        }
        
        vm.stopPrank();
        
        // Return estimated values (should actually call Router)
        return (amountSpecified > 0 ? amountSpecified : -amountSpecified / 2, 
                amountSpecified > 0 ? -amountSpecified / 2 : amountSpecified);
    }
    
    /**
     * Calculate price limit
     */
    function _calculatePriceLimit(
        uint160 currentSqrtPrice,
        bool zeroForOne,
        uint256 slippagePercent
    ) internal pure returns (uint160) {
        if (zeroForOne) {
            // Selling Token0, price drops
            return uint160(uint256(currentSqrtPrice) * (100 - slippagePercent) / 100);
        } else {
            // Selling Token1, price rises
            return uint160(uint256(currentSqrtPrice) * (100 + slippagePercent) / 100);
        }
    }
    
    /**
     * Calculate price from sqrtPriceX96
     */
    function _getPriceFromSqrtPriceX96(uint160 sqrtPriceX96) internal pure returns (uint256) {
        // price = (sqrtPrice / 2^96)^2
        // Simplified calculation, high-precision math library needed for production
        uint256 Q96 = 2**96;
        return (uint256(sqrtPriceX96) * uint256(sqrtPriceX96) * 1e18) / (Q96 * Q96);
    }
    
    /**
     * Send WETH to address
     */
    function _giveWETH(address to, uint256 amount) internal {
        // Transfer from WETH holder on Base (simplified: direct mint)
        vm.store(WETH, keccak256(abi.encode(to, 3)), bytes32(amount)); // Directly modify storage slot
        
        // Or use deal
        vm.deal(address(this), amount);
        IWETH(WETH).deposit{value: amount}();
        weth.transfer(to, amount);
    }
    
    /**
     * Send USDC to address
     */
    function _giveUSDC(address to, uint256 amount) internal {
        // USDC is centralized, transfer from whale
        // Try a wide range of common storage slots for ERC20 balances.
        for (uint256 slot = 0; slot < 16; slot++) {
            vm.store(USDC, keccak256(abi.encode(to, slot)), bytes32(amount));
        }
    }
}
