@echo off
REM Foundry Fork 测试运行脚本 (Windows)

echo ========================================
echo CLPool Swap Foundry Fork 测试
echo ========================================
echo.

REM 检查 forge 是否安装
where forge >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 错误: 未找到 forge 命令
    echo.
    echo 请先安装 Foundry:
    echo curl -L https://foundry.paradigm.xyz ^| bash
    echo foundryup
    echo.
    pause
    exit /b 1
)

echo ✅ Foundry 已安装
echo.

REM 选择测试
echo 请选择要运行的测试:
echo.
echo 1. testInspectPool    - 查看池子状态
echo 2. testSmallSwap      - 小额交易 (0.001 WETH)
echo 3. testMediumSwap     - 中等交易 (0.01 WETH)
echo 4. testLargeSwap      - 大额交易 (0.1 WETH)
echo 5. testReverseSwap    - 反向交易 (USDC → WETH)
echo 6. testExactOutput    - 精确输出模式
echo 7. 运行所有测试
echo.
set /p choice="请输入选项 (1-7): "

echo.
echo 🚀 开始执行...
echo.

if "%choice%"=="1" (
    forge test --match-test testInspectPool -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="2" (
    forge test --match-test testSmallSwap -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="3" (
    forge test --match-test testMediumSwap -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="4" (
    forge test --match-test testLargeSwap -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="5" (
    forge test --match-test testReverseSwap -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="6" (
    forge test --match-test testExactOutputSwap -vvv --fork-url https://mainnet.base.org
) else if "%choice%"=="7" (
    forge test --match-path test/CLPoolSwap.t.sol -vvv --fork-url https://mainnet.base.org
) else (
    echo ❌ 无效选项
    pause
    exit /b 1
)

echo.
echo ========================================
echo 测试完成!
echo ========================================
pause
