# CLPool Swap 模拟交易详解

## 📊 实际池子数据（来自 BaseScan）

**Pool 地址**: [`0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59`](https://basescan.org/address/0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59)

### 池子信息

```
Token0: 0x4200000000000000000000000000000000000006 (WETH - Wrapped ETH)
Token1: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 (USDC)
当前 Tick: -198839
流动性: ~26,376,205,795,352,851,473
费率: 0.04% (4 basis points)
池子状态: ✅ Unlocked
```

---

## 🎯 模拟交易场景

### 场景 1: 小额交易 - 卖出 0.001 WETH

**调用参数**:
```javascript
recipient:        '0xYourWalletAddress'
zeroForOne:       true              // WETH → USDC
amountSpecified:  1000000000000000  // 0.001 * 10^18 (wei)
sqrtPriceLimitX96: 计算值（允许5%滑点）
data:             '0x'              // callback 数据
```

**预期结果**:
- **支付**: 0.001 WETH
- **收到**: ~2.5 USDC（根据当前价格）
- **手续费**: 0.0000004 WETH
- **Gas 费用**: ~$0.01-0.05（Base 链很便宜）

---

### 场景 2: 中等交易 - 卖出 0.01 WETH

**调用参数**:
```javascript
amountSpecified:  10000000000000000  // 0.01 * 10^18
```

**预期结果**:
- **支付**: 0.01 WETH
- **收到**: ~25 USDC
- **价格影响**: < 0.1%
- **手续费**: 0.000004 WETH

---

### 场景 3: 大额交易 - 卖出 0.1 WETH

**调用参数**:
```javascript
amountSpecified:  100000000000000000  // 0.1 * 10^18
```

**预期结果**:
- **支付**: 0.1 WETH
- **收到**: ~250 USDC
- **价格影响**: ~0.5-1%
- **可能跨越多个 tick**，流动性会变化

---

### 场景 4: 超大额交易 - 卖出 1.0 WETH

**调用参数**:
```javascript
amountSpecified:  1000000000000000000  // 1.0 * 10^18
```

**预期结果**:
- **支付**: 1.0 WETH
- **收到**: ~2500 USDC（但滑点很大）
- **价格影响**: 可能 > 5%
- **强烈建议设置更大的 sqrtPriceLimitX96**

---

## 🔧 实际调用代码示例

### 方法 1: 通过 Router（推荐）

```javascript
const { Web3 } = require('web3');

const web3 = new Web3('https://mainnet.base.org');

// Uniswap V3 Router ABI（简化）
const ROUTER_ABI = [
    {
        "inputs": [
            {
                "components": [
                    { "internalType": "address", "name": "tokenIn", "type": "address" },
                    { "internalType": "address", "name": "tokenOut", "type": "address" },
                    { "internalType": "uint24", "name": "fee", "type": "uint24" },
                    { "internalType": "address", "name": "recipient", "type": "address" },
                    { "internalType": "uint256", "name": "deadline", "type": "uint256" },
                    { "internalType": "uint256", "name": "amountIn", "type": "uint256" },
                    { "internalType": "uint256", "name": "amountOutMinimum", "type": "uint256" },
                    { "internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160" }
                ],
                "internalType": "struct ISwapRouter.ExactInputSingleParams",
                "name": "params",
                "type": "tuple"
            }
        ],
        "name": "exactInputSingle",
        "outputs": [{ "internalType": "uint256", "name": "amountOut", "type": "uint256" }],
        "stateMutability": "payable",
        "type": "function"
    }
];

const ROUTER_ADDRESS = '0x2626664c2603336E57B271c5C0b26F421741e481'; // Base 链 Uniswap Router

async function swapViaRouter() {
    const router = new web3.eth.Contract(ROUTER_ABI, ROUTER_ADDRESS);
    
    const params = {
        tokenIn: '0x4200000000000000000000000000000000000006',      // WETH
        tokenOut: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',   // USDC
        fee: 400,                                                  // 0.04%
        recipient: '0xYourWalletAddress',
        deadline: Math.floor(Date.now() / 1000) + 60 * 20,        // 20分钟后过期
        amountIn: web3.utils.toWei('0.01', 'ether'),               // 0.01 WETH
        amountOutMinimum: web3.utils.toWei('20', 'mwei'),          // 最少收到 20 USDC
        sqrtPriceLimitX96: 0                                       // 无限制
    };
    
    // 估算 Gas
    const gas = await router.methods.exactInputSingle(params).estimateGas({
        from: '0xYourWalletAddress'
    });
    
    console.log(`预估 Gas: ${gas}`);
    
    // 执行交易（需要私钥）
    // const tx = await router.methods.exactInputSingle(params).send({
    //     from: '0xYourWalletAddress',
    //     gas: gas
    // });
    
    console.log('交易哈希:', tx.transactionHash);
}
```

---

### 方法 2: 直接调用 Pool（高级）

```javascript
const POOL_ABI = [
    {
        "inputs": [
            { "internalType": "address", "name": "recipient", "type": "address" },
            { "internalType": "bool", "name": "zeroForOne", "type": "bool" },
            { "internalType": "int256", "name": "amountSpecified", "type": "int256" },
            { "internalType": "uint160", "name": "sqrtPriceLimitX96", "type": "uint160" },
            { "internalType": "bytes", "name": "data", "type": "bytes" }
        ],
        "name": "swap",
        "outputs": [
            { "internalType": "int256", "name": "amount0", "type": "int256" },
            { "internalType": "int256", "name": "amount1", "type": "int256" }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];

const POOL_ADDRESS = '0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59';

async function directSwap() {
    const pool = new web3.eth.Contract(POOL_ABI, POOL_ADDRESS);
    
    // 你的合约必须实现 ICLSwapCallback 接口
    const YOUR_CONTRACT = '0xYourContractAddress';
    
    const tx = await pool.methods.swap(
        YOUR_CONTRACT,           // recipient
        true,                    // zeroForOne (WETH → USDC)
        web3.utils.toWei('0.01', 'ether'),  // amountSpecified
        calculatePriceLimit(),   // sqrtPriceLimitX96
        '0x'                     // data
    ).send({
        from: YOUR_CONTRACT,
        gas: 300000
    });
    
    console.log('交易完成:', tx.transactionHash);
}

// 在你的合约中实现 callback
/*
contract MySwapContract is ICLSwapCallback {
    function uniswapV3SwapCallback(
        int256 amount0Delta,
        int256 amount1Delta,
        bytes calldata data
    ) external override {
        // Pool 调用这个函数要求你转入代币
        if (amount0Delta > 0) {
            // 需要转入 Token0 (WETH)
            IWETH(WETH).deposit{value: uint256(amount0Delta)}();
            IWETH(WETH).transfer(msg.sender, uint256(amount0Delta));
        }
    }
}
*/
```

---

## 📈 关键参数详解

### 1. `sqrtPriceLimitX96` 如何计算？

```javascript
// 从 Pool 获取当前价格
const slot0 = await pool.methods.slot0().call();
const currentSqrtPrice = BigInt(slot0.sqrtPriceX96);

// 允许 5% 滑点
const slippageBps = 500; // 5% = 500 basis points
const priceLimit = currentSqrtPrice * BigInt(10000 - slippageBps) / BigInt(10000);

console.log('当前价格:', currentSqrtPrice.toString());
console.log('价格限制:', priceLimit.toString());
```

**原理**:
- `sqrtPriceX96` 是价格的平方根 × 2^96
- zeroForOne 时，价格会下降，所以 limit < current
- oneForZero 时，价格会上升，所以 limit > current

---

### 2. `amountSpecified` 正负含义

```javascript
// 精确输入：我想卖出 0.01 WETH，能买到多少 USDC？
const exactInput = web3.utils.toWei('0.01', 'ether');  // 正数

// 精确输出：我想买入 100 USDC，需要支付多少 WETH？
const exactOutput = -web3.utils.toWei('100', 'mwei');  // 负数
```

---

### 3. Callback 机制

**为什么需要 callback？**

Uniswap V3 采用 **"先给后收"** 模式：
1. Pool 先把你想要的代币转给你
2. 然后调用你的 `uniswapV3SwapCallback`
3. 你在 callback 中把要卖的代币转给 Pool
4. Pool 验证余额是否增加

**安全性**: 防止你拿了代币不给钱！

---

## 💡 实战建议

### ✅ 推荐做法

1. **使用 Router 而非直接调用 Pool**
   - Router 自动处理 callback
   - 支持多跳路由
   - 内置滑点保护

2. **设置合理的价格限制**
   - 小额交易：1-2% 滑点
   - 大额交易：可能需要分笔执行

3. **先 approve 再 swap**
   ```javascript
   // 授权 Router 使用你的 WETH
   await weth.methods.approve(ROUTER_ADDRESS, amountIn).send({ from: wallet });
   ```

4. **检查余额变化**
   ```javascript
   const balanceBefore = await usdc.methods.balanceOf(wallet).call();
   await swap();
   const balanceAfter = await usdc.methods.balanceOf(wallet).call();
   console.log('实际收到:', balanceAfter - balanceBefore);
   ```

---

## 🔗 相关资源

- **[Revert Finance Pool on BaseScan](https://basescan.org/address/0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59)** - 查看实时交易
- **[Uniswap V3 官方文档](https://docs.uniswap.org/contracts/v3/overview)** - 完整技术文档
- **[Uniswap V3 Core GitHub](https://github.com/Uniswap/v3-core)** - 源代码
- **[Base 链区块浏览器](https://basescan.org/)** - 查看所有交易
- **[Revert Finance UI](https://revert.finance/)** - 图形界面交易

---

## ⚠️ 注意事项

1. **测试网先试**
   - 先在 Base Sepolia 测试网练习
   - 确认逻辑正确后再上主网

2. **Gas 费用**
   - Base 链 Gas 很便宜（~$0.01-0.1）
   - 但仍需预留 BNB/ETH 作为 Gas

3. **滑点风险**
   - 大额交易前检查流动性深度
   - 考虑分笔执行减少冲击

4. **MEV 保护**
   - 使用 Flashbots 或私有 RPC
   - 避免被三明治攻击

5. **时间锁**
   - 设置合理的 deadline
   - 避免交易长时间 pending
