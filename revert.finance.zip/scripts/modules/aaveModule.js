/**
 * AAVE 数据获取模块
 */

const { Web3 } = require('web3');
const ExcelJS = require('exceljs');
const path = require('path');

// AAVE V3 Pool 地址配置
const AAVE_POOL_ADDRESSES = {
  1: '0x2f39d218133AFaB8F2B819B1066c7E434Ad94E9e',
  137: '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb',
  43114: '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb',
  42161: '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb',
  10: '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb',
  250: '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb',
  56: '0x6807dc923806fE8Fd134338EABCA509979a7e0cB',
};

const MULTICALL_ADDRESSES = {
  1: '0xcA11bde05977b3631167028862bE2a173976CA11',
  56: '0xcA11bde05977b3631167028862bE2a173976CA11',
  137: '0xcA11bde05977b3631167028862bE2a173976CA11',
  43114: '0xcA11bde05977b3631167028862bE2a173976CA11',
  42161: '0xcA11bde05977b3631167028862bE2a173976CA11',
  10: '0xcA11bde05977b3631167028862bE2a173976CA11',
  250: '0xcA11bde05977b3631167028862bE2a173976CA11',
};

const AAVE_POOL_ABI = [
  {
    "inputs": [],
    "name": "getReservesList",
    "outputs": [{ "internalType": "address[]", "name": "", "type": "address[]" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "asset", "type": "address" }],
    "name": "getReserveData",
    "outputs": [{
      "components": [
        { "components": [{ "internalType": "uint256", "name": "data", "type": "uint256" }],
          "internalType": "struct DataTypes.ReserveConfigurationMap", "name": "configuration", "type": "tuple" },
        { "internalType": "uint128", "name": "liquidityIndex", "type": "uint128" },
        { "internalType": "uint128", "name": "currentLiquidityRate", "type": "uint128" },
        { "internalType": "uint128", "name": "variableBorrowIndex", "type": "uint128" },
        { "internalType": "uint128", "name": "currentVariableBorrowRate", "type": "uint128" },
        { "internalType": "uint128", "name": "currentStableBorrowRate", "type": "uint128" },
        { "internalType": "uint40", "name": "lastUpdateTimestamp", "type": "uint40" },
        { "internalType": "uint16", "name": "id", "type": "uint16" },
        { "internalType": "address", "name": "aTokenAddress", "type": "address" },
        { "internalType": "address", "name": "stableDebtTokenAddress", "type": "address" },
        { "internalType": "address", "name": "variableDebtTokenAddress", "type": "address" },
        { "internalType": "address", "name": "interestRateStrategyAddress", "type": "address" },
        { "internalType": "uint128", "name": "accruedToTreasury", "type": "uint128" },
        { "internalType": "uint128", "name": "unbacked", "type": "uint128" },
        { "internalType": "uint128", "name": "isolationModeTotalDebt", "type": "uint128" }
      ],
      "internalType": "struct DataTypes.ReserveData", "name": "", "type": "tuple"
    }],
    "stateMutability": "view",
    "type": "function"
  }
];

const ERC20_ABI = [
  { "inputs": [], "name": "symbol", "outputs": [{ "name": "", "type": "string" }], "stateMutability": "view", "type": "function" },
  { "inputs": [], "name": "decimals", "outputs": [{ "name": "", "type": "uint8" }], "stateMutability": "view", "type": "function" },
  { "inputs": [], "name": "name", "outputs": [{ "name": "", "type": "string" }], "stateMutability": "view", "type": "function" },
  { "inputs": [], "name": "totalSupply", "outputs": [{ "name": "", "type": "uint256" }], "stateMutability": "view", "type": "function" },
  { "inputs": [{ "name": "account", "type": "address" }], "name": "balanceOf", "outputs": [{ "name": "", "type": "uint256" }], "stateMutability": "view", "type": "function" }
];

const MULTICALL_ABI = [
  {
    "inputs": [{
      "components": [
        { "internalType": "address", "name": "target", "type": "address" },
        { "internalType": "bytes", "name": "callData", "type": "bytes" }
      ],
      "internalType": "struct Multicall2.Call[]", "name": "calls", "type": "tuple[]"
    }],
    "name": "aggregate",
    "outputs": [
      { "internalType": "uint256", "name": "blockNumber", "type": "uint256" },
      { "internalType": "bytes[]", "name": "returnData", "type": "bytes[]" }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

// Aave V3 Interest Rate Strategy ABI（用于获取利率参数）
const INTEREST_RATE_STRATEGY_ABI = [
  {
    "inputs": [{ "internalType": "address", "name": "reserve", "type": "address" }],
    "name": "getOptimalUsageRatio",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "reserve", "type": "address" }],
    "name": "getBaseVariableBorrowRate",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "reserve", "type": "address" }],
    "name": "getVariableRateSlope1",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "reserve", "type": "address" }],
    "name": "getVariableRateSlope2",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  }
];

/**
 * 步骤1: 初始化 Web3 和合约
 */
async function initAAVE(context) {
  const { chainId = 56, rpcUrl = 'https://bsc.publicnode.com' } = context;
  
  const web3 = new Web3(rpcUrl);
  const poolAddress = AAVE_POOL_ADDRESSES[chainId];
  const multicallAddress = MULTICALL_ADDRESSES[chainId];

  if (!poolAddress) throw new Error(`不支持的链 ID: ${chainId}`);
  if (!multicallAddress) throw new Error(`链 ${chainId} 缺少 Multicall 地址`);

  console.log(`✓ 连接到链 ID: ${chainId}`);
  console.log(`✓ AAVE Pool: ${poolAddress}`);
  console.log(`✓ Multicall: ${multicallAddress}`);

  return {
    web3,
    chainId,
    poolContract: new web3.eth.Contract(AAVE_POOL_ABI, poolAddress),
    multicallContract: new web3.eth.Contract(MULTICALL_ABI, multicallAddress)
  };
}

/**
 * 步骤2: 获取 Reserves 列表
 */
async function fetchReservesList(context) {
  const { poolContract } = context;
  console.log('正在获取 Reserves 列表...');
  
  const reserves = await poolContract.methods.getReservesList().call();
  console.log(`✓ 找到 ${reserves.length} 个 Reserve`);
  
  return { reserveAddresses: reserves };
}

/**
 * 步骤3: 批量获取 Reserve 数据
 */
async function fetchReserveData(context) {
  const { web3, poolContract, multicallContract, reserveAddresses } = context;
  const poolAddress = poolContract.options.address;

  console.log(`正在批量获取 ${reserveAddresses.length} 个 Reserve 数据...`);
  
  const queries = reserveAddresses.map(asset => [
    poolAddress,
    poolContract.methods.getReserveData(asset).encodeABI()
  ]);

  const { returnData } = await multicallContract.methods.aggregate(queries).call();

  const results = [];
  for (let i = 0; i < returnData.length; i++) {
    try {
      const reserveData = web3.eth.abi.decodeParameters([{
        "components": [
          { "components": [{ "name": "data", "type": "uint256" }], "name": "configuration", "type": "tuple" },
          { "name": "liquidityIndex", "type": "uint128" },
          { "name": "currentLiquidityRate", "type": "uint128" },
          { "name": "variableBorrowIndex", "type": "uint128" },
          { "name": "currentVariableBorrowRate", "type": "uint128" },
          { "name": "currentStableBorrowRate", "type": "uint128" },
          { "name": "lastUpdateTimestamp", "type": "uint40" },
          { "name": "id", "type": "uint16" },
          { "name": "aTokenAddress", "type": "address" },
          { "name": "stableDebtTokenAddress", "type": "address" },
          { "name": "variableDebtTokenAddress", "type": "address" },
          { "name": "interestRateStrategyAddress", "type": "address" },
          { "name": "accruedToTreasury", "type": "uint128" },
          { "name": "unbacked", "type": "uint128" },
          { "name": "isolationModeTotalDebt", "type": "uint128" }
        ],
        "name": "reserveData",
        "type": "tuple"
      }], returnData[i]).reserveData;

      results.push({ address: reserveAddresses[i], ...reserveData });
    } catch (error) {
      console.warn(`⚠ 解析 Reserve ${reserveAddresses[i]} 失败`);
    }
  }

  console.log(`✓ 成功获取 ${results.length} 个 Reserve 数据`);
  return { reserveDataList: results };
}

/**
 * 步骤4: 批量获取代币信息
 */
async function fetchTokenInfo(context) {
  const { web3, multicallContract, reserveDataList } = context;

  console.log('正在获取代币基本信息...');
  
  const queries = [];
  const tokenAddresses = reserveDataList.map(r => r.address);
  
  tokenAddresses.forEach(tokenAddress => {
    const erc20 = new web3.eth.Contract(ERC20_ABI, tokenAddress);
    queries.push([tokenAddress, erc20.methods.symbol().encodeABI()]);
    queries.push([tokenAddress, erc20.methods.decimals().encodeABI()]);
    queries.push([tokenAddress, erc20.methods.name().encodeABI()]);
  });

  const { returnData } = await multicallContract.methods.aggregate(queries).call();

  const tokenInfoMap = {};
  for (let i = 0; i < returnData.length; i += 3) {
    const tokenIndex = i / 3;
    const address = tokenAddresses[tokenIndex];
    
    try {
      tokenInfoMap[address] = {
        symbol: web3.eth.abi.decodeParameter('string', returnData[i]),
        decimals: parseInt(returnData[i + 1]),
        name: web3.eth.abi.decodeParameter('string', returnData[i + 2])
      };
    } catch (error) {
      tokenInfoMap[address] = { symbol: 'UNKNOWN', decimals: 18, name: 'Unknown Token' };
    }
  }

  console.log(`✓ 成功获取 ${Object.keys(tokenInfoMap).length} 个代币信息`);
  return { tokenInfoMap };
}

/**
 * 步骤5: 批量获取 aToken 相关信息
 */
async function fetchATokenBalances(context) {
  const { web3, multicallContract, reserveDataList } = context;

  console.log('正在获取 aToken 信息（totalSupply + 底层资产余额）...');
  
  // 构建查询：每个 reserve 需要两个查询
  // 1. aToken.totalSupply() - aToken 发行量
  // 2. underlyingToken.balanceOf(aTokenAddress) - 底层资产在 aToken 中的余额
  const queries = [];
  
  reserveDataList.forEach(reserve => {
    const underlyingTokenAddress = reserve.address;  // 底层资产地址
    const aTokenAddress = reserve.aTokenAddress;      // aToken 合约地址
    
    // 查询1: aToken.totalSupply()
    const aTokenContract = new web3.eth.Contract(ERC20_ABI, aTokenAddress);
    queries.push([aTokenAddress, aTokenContract.methods.totalSupply().encodeABI()]);
    
    // 查询2: underlyingToken.balanceOf(aTokenAddress)
    const underlyingTokenContract = new web3.eth.Contract(ERC20_ABI, underlyingTokenAddress);
    queries.push([underlyingTokenAddress, underlyingTokenContract.methods.balanceOf(aTokenAddress).encodeABI()]);
  });

  const { returnData } = await multicallContract.methods.aggregate(queries).call();

  // 将结果映射到对应的 reserve
  const aTokenBalanceMap = {};
  for (let i = 0; i < reserveDataList.length; i++) {
    const reserve = reserveDataList[i];
    const reserveAddress = reserve.address;
    const aTokenAddress = reserve.aTokenAddress;
    const decimals = reserve.decimals || 18;
    
    try {
      // 解析两个返回值
      const aTokenTotalSupply = BigInt(returnData[i * 2]);
      const underlyingAssetBalance = BigInt(returnData[i * 2 + 1]);
      
      // 转换为可读格式
      const formattedATokenSupply = (Number(aTokenTotalSupply) / Math.pow(10, decimals)).toFixed(2);
      const formattedUnderlyingBalance = (Number(underlyingAssetBalance) / Math.pow(10, decimals)).toFixed(2);
      
      aTokenBalanceMap[reserveAddress] = {
        aTokenAddress,
        aTokenTotalSupply: aTokenTotalSupply.toString(),
        aTokenFormattedSupply: formattedATokenSupply,
        underlyingAssetInAToken: underlyingAssetBalance.toString(),
        underlyingAssetFormattedBalance: formattedUnderlyingBalance
      };
    } catch (error) {
      console.warn(`⚠ 获取 ${reserve.symbol} 的 aToken 信息失败`);
      aTokenBalanceMap[reserveAddress] = {
        aTokenAddress,
        aTokenTotalSupply: '0',
        aTokenFormattedSupply: '0.00',
        underlyingAssetInAToken: '0',
        underlyingAssetFormattedBalance: '0.00'
      };
    }
  }

  console.log(`✓ 成功获取 ${Object.keys(aTokenBalanceMap).length} 个 aToken 信息`);
  return { aTokenBalanceMap };
}

/**
 * 步骤5.5: 批量获取债务代币供应量（用于计算使用率）
 */
async function fetchDebtTokenSupplies(context) {
  const { web3, multicallContract, reserveDataList } = context;

  console.log('正在获取债务代币供应量（Variable + Stable Debt）...');
  
  // 为每个 reserve 构建两个查询
  const queries = [];
  
  reserveDataList.forEach(reserve => {
    const variableDebtAddress = reserve.variableDebtTokenAddress;
    const stableDebtAddress = reserve.stableDebtTokenAddress;
    
    // 查询1: variableDebtToken.totalSupply()
    if (variableDebtAddress && variableDebtAddress !== '0x0000000000000000000000000000000000000000') {
      const variableDebtContract = new web3.eth.Contract(ERC20_ABI, variableDebtAddress);
      queries.push([variableDebtAddress, variableDebtContract.methods.totalSupply().encodeABI()]);
    } else {
      queries.push(null); // 占位符
    }
    
    // 查询2: stableDebtToken.totalSupply()
    if (stableDebtAddress && stableDebtAddress !== '0x0000000000000000000000000000000000000000') {
      const stableDebtContract = new web3.eth.Contract(ERC20_ABI, stableDebtAddress);
      queries.push([stableDebtAddress, stableDebtContract.methods.totalSupply().encodeABI()]);
    } else {
      queries.push(null); // 占位符
    }
  });

  // 过滤掉 null 值，只执行有效查询
  const validQueries = queries.filter(q => q !== null);
  
  let debtSupplies = {};
  if (validQueries.length > 0) {
    const { returnData } = await multicallContract.methods.aggregate(validQueries).call();
    
    // 将结果映射回对应的 reserve
    let dataIndex = 0;
    for (let i = 0; i < reserveDataList.length; i++) {
      const reserve = reserveDataList[i];
      const reserveAddress = reserve.address;
      const decimals = reserve.decimals || 18;
      
      try {
        // Variable Debt
        let variableDebtSupply = BigInt(0);
        if (queries[i * 2] !== null && dataIndex < returnData.length) {
          variableDebtSupply = BigInt(returnData[dataIndex]);
          dataIndex++;
        }
        
        // Stable Debt
        let stableDebtSupply = BigInt(0);
        if (queries[i * 2 + 1] !== null && dataIndex < returnData.length) {
          stableDebtSupply = BigInt(returnData[dataIndex]);
          dataIndex++;
        }
        
        const totalDebt = variableDebtSupply + stableDebtSupply;
        
        debtSupplies[reserveAddress] = {
          variableDebtSupply: variableDebtSupply.toString(),
          stableDebtSupply: stableDebtSupply.toString(),
          totalDebtSupply: totalDebt.toString(),
          variableDebtFormatted: (Number(variableDebtSupply) / Math.pow(10, decimals)).toFixed(2),
          stableDebtFormatted: (Number(stableDebtSupply) / Math.pow(10, decimals)).toFixed(2),
          totalDebtFormatted: (Number(totalDebt) / Math.pow(10, decimals)).toFixed(2)
        };
      } catch (error) {
        console.warn(`⚠ 获取 ${reserve.symbol} 的债务数据失败`);
        debtSupplies[reserveAddress] = {
          variableDebtSupply: '0',
          stableDebtSupply: '0',
          totalDebtSupply: '0',
          variableDebtFormatted: '0.00',
          stableDebtFormatted: '0.00',
          totalDebtFormatted: '0.00'
        };
      }
    }
  }

  console.log(`✓ 成功获取 ${Object.keys(debtSupplies).length} 个债务代币数据`);
  return { debtSupplies };
}

/**
 * 步骤5.6: 批量获取利率策略参数（Optimal Utilization, BaseRate, Slope1, Slope2）
 */
async function fetchInterestRateStrategyParams(context) {
  const { web3, multicallContract, reserveDataList } = context;

  console.log('正在获取利率策略参数（Optimal Utilization, BaseRate, Slope1, Slope2）...');
  
  // 为每个 reserve 构建4个查询：optimalUsageRatio, baseRate, slope1, slope2
  const queries = [];
  
  reserveDataList.forEach(reserve => {
    const strategyAddress = reserve.interestRateStrategyAddress;
    const reserveAddress = reserve.address;
    
    if (strategyAddress && strategyAddress !== '0x0000000000000000000000000000000000000000') {
      const strategyContract = new web3.eth.Contract(INTEREST_RATE_STRATEGY_ABI, strategyAddress);
      
      // 4个查询：optimalUsageRatio, baseRate, slope1, slope2
      queries.push([strategyAddress, strategyContract.methods.getOptimalUsageRatio(reserveAddress).encodeABI()]);
      queries.push([strategyAddress, strategyContract.methods.getBaseVariableBorrowRate(reserveAddress).encodeABI()]);
      queries.push([strategyAddress, strategyContract.methods.getVariableRateSlope1(reserveAddress).encodeABI()]);
      queries.push([strategyAddress, strategyContract.methods.getVariableRateSlope2(reserveAddress).encodeABI()]);
    } else {
      // 占位符（4个 null）
      queries.push(null, null, null, null);
    }
  });

  // 过滤掉 null 值，只执行有效查询
  const validQueries = queries.filter(q => q !== null);
  
  let strategyParams = {};
  
  // 初始化所有 reserve 的默认值
  reserveDataList.forEach(reserve => {
    strategyParams[reserve.address] = {
      optimalUtilizationRate: '0',
      optimalUtilizationRatePercent: 'N/A',
      baseVariableBorrowRate: '0',
      baseVariableBorrowRatePercent: 'N/A',
      variableRateSlope1: '0',
      variableRateSlope1Percent: 'N/A',
      variableRateSlope2: '0',
      variableRateSlope2Percent: 'N/A'
    };
  });
  
  if (validQueries.length > 0) {
    try {
      const { returnData } = await multicallContract.methods.aggregate(validQueries).call();
      
      // 将结果映射回对应的 reserve（每4个一组）
      let dataIndex = 0;
      for (let i = 0; i < reserveDataList.length; i++) {
        const reserve = reserveDataList[i];
        const reserveAddress = reserve.address;
        
        if (queries[i * 4] !== null && dataIndex + 3 < returnData.length) {
          try {
            const optimalUsageRatio = BigInt(returnData[dataIndex]);
            const baseRate = BigInt(returnData[dataIndex + 1]);
            const slope1 = BigInt(returnData[dataIndex + 2]);
            const slope2 = BigInt(returnData[dataIndex + 3]);
            dataIndex += 4;
            
            // Ray to Percent 转换（注意：先除后乘）
            const RAY = BigInt('1000000000000000000000000000');
            
            const optimalDecimal = Number(optimalUsageRatio) / Number(RAY);
            const baseDecimal = Number(baseRate) / Number(RAY);
            const slope1Decimal = Number(slope1) / Number(RAY);
            const slope2Decimal = Number(slope2) / Number(RAY);
            
            strategyParams[reserveAddress] = {
              optimalUtilizationRate: optimalUsageRatio.toString(),
              optimalUtilizationRatePercent: (optimalDecimal * 100).toFixed(2) + '%',
              baseVariableBorrowRate: baseRate.toString(),
              baseVariableBorrowRatePercent: (baseDecimal * 100).toFixed(2) + '%',
              variableRateSlope1: slope1.toString(),
              variableRateSlope1Percent: (slope1Decimal * 100).toFixed(2) + '%',
              variableRateSlope2: slope2.toString(),
              variableRateSlope2Percent: (slope2Decimal * 100).toFixed(2) + '%'
            };
          } catch (error) {
            console.warn(`⚠ 解析 ${reserve.symbol} 的利率策略参数失败`);
            dataIndex += 4; // 跳过这4个数据
          }
        }
      }
      
      console.log(`✓ 成功获取 ${Object.keys(strategyParams).length} 个利率策略参数`);
    } catch (error) {
      console.warn('⚠ 批量获取利率策略参数失败，尝试逐个查询...');
      
      // 降级方案：逐个查询
      for (let i = 0; i < reserveDataList.length; i++) {
        const reserve = reserveDataList[i];
        const strategyAddress = reserve.interestRateStrategyAddress;
        const reserveAddress = reserve.address;
        
        if (strategyAddress && strategyAddress !== '0x0000000000000000000000000000000000000000') {
          try {
            const strategyContract = new web3.eth.Contract(INTEREST_RATE_STRATEGY_ABI, strategyAddress);
            
            const [optimalUsageRatio, baseRate, slope1, slope2] = await Promise.all([
              strategyContract.methods.getOptimalUsageRatio(reserveAddress).call(),
              strategyContract.methods.getBaseVariableBorrowRate(reserveAddress).call(),
              strategyContract.methods.getVariableRateSlope1(reserveAddress).call(),
              strategyContract.methods.getVariableRateSlope2(reserveAddress).call()
            ]);
            
            const RAY = BigInt('1000000000000000000000000000');
            
            const optimalDecimal = Number(BigInt(optimalUsageRatio)) / Number(RAY);
            const baseDecimal = Number(BigInt(baseRate)) / Number(RAY);
            const slope1Decimal = Number(BigInt(slope1)) / Number(RAY);
            const slope2Decimal = Number(BigInt(slope2)) / Number(RAY);
            
            strategyParams[reserveAddress] = {
              optimalUtilizationRate: optimalUsageRatio.toString(),
              optimalUtilizationRatePercent: (optimalDecimal * 100).toFixed(2) + '%',
              baseVariableBorrowRate: baseRate.toString(),
              baseVariableBorrowRatePercent: (baseDecimal * 100).toFixed(2) + '%',
              variableRateSlope1: slope1.toString(),
              variableRateSlope1Percent: (slope1Decimal * 100).toFixed(2) + '%',
              variableRateSlope2: slope2.toString(),
              variableRateSlope2Percent: (slope2Decimal * 100).toFixed(2) + '%'
            };
            
            console.log(`  ✓ ${reserve.symbol}: Optimal=${(optimalDecimal * 100).toFixed(2)}%, Base=${(baseDecimal * 100).toFixed(2)}%`);
          } catch (err) {
            console.warn(`  ⚠ ${reserve.symbol}: 无法获取参数`);
          }
        }
      }
      
      console.log(`✓ 降级方案完成，获取了部分利率策略参数`);
    }
  } else {
    console.log('⚠ 没有有效的利率策略地址');
  }
  
  return { strategyParams };
}

/**
 * 工具函数: Ray 转百分比
 */
function rayToPercent(ray) {
  const RAY = BigInt('1000000000000000000000000000');
  const percent = (ray * BigInt(10000)) / RAY;
  return Number(percent) / 100;
}

/**
 * 工具函数: 格式化时间戳
 */
function formatTimestamp(timestamp) {
  return new Date(Number(timestamp) * 1000).toLocaleString('zh-CN');
}

/**
 * 步骤6: 整合数据并计算使用率
 */
function mergeData(context) {
  const { reserveDataList, tokenInfoMap, aTokenBalanceMap, debtSupplies, strategyParams } = context;
  
  const mergedData = reserveDataList.map(reserve => {
    const tokenInfo = tokenInfoMap[reserve.address] || {};
    const aTokenBalance = aTokenBalanceMap[reserve.address] || {};
    const debtData = debtSupplies?.[reserve.address] || {};
    const strategyParam = strategyParams?.[reserve.address] || {};
    
    // 计算资产使用率
    let utilizationRate = '0.00%';
    try {
      const totalSupplied = BigInt(aTokenBalance.aTokenTotalSupply || '0');
      const totalBorrowed = BigInt(debtData.totalDebtSupply || '0');
      
      if (totalSupplied > BigInt(0)) {
        const rate = (totalBorrowed * BigInt(10000)) / totalSupplied;
        utilizationRate = (Number(rate) / 100).toFixed(2) + '%';
      }
    } catch (error) {
      utilizationRate = 'N/A';
    }
    
    return {
      symbol: tokenInfo.symbol || 'N/A',
      name: tokenInfo.name || 'N/A',
      decimals: tokenInfo.decimals || 18,
      address: reserve.address,
      id: Number(reserve.id),
      liquidityRate: rayToPercent(BigInt(reserve.currentLiquidityRate)).toFixed(2) + '%',
      variableBorrowRate: rayToPercent(BigInt(reserve.currentVariableBorrowRate)).toFixed(2) + '%',
      stableBorrowRate: rayToPercent(BigInt(reserve.currentStableBorrowRate)).toFixed(2) + '%',
      utilizationRate: utilizationRate,
      optimalUtilizationRate: strategyParam.optimalUtilizationRatePercent || 'N/A',
      baseVariableBorrowRate: strategyParam.baseVariableBorrowRatePercent || 'N/A',
      variableRateSlope1: strategyParam.variableRateSlope1Percent || 'N/A',
      variableRateSlope2: strategyParam.variableRateSlope2Percent || 'N/A',
      liquidityIndex: reserve.liquidityIndex.toString(),
      variableBorrowIndex: reserve.variableBorrowIndex.toString(),
      lastUpdateTimestamp: formatTimestamp(reserve.lastUpdateTimestamp),
      aTokenAddress: reserve.aTokenAddress,
      aTokenTotalSupply: aTokenBalance.aTokenTotalSupply || '0',
      aTokenFormattedSupply: aTokenBalance.aTokenFormattedSupply || '0.00',
      underlyingAssetInAToken: aTokenBalance.underlyingAssetInAToken || '0',
      underlyingAssetFormattedBalance: aTokenBalance.underlyingAssetFormattedBalance || '0.00',
      variableDebtSupply: debtData.variableDebtSupply || '0',
      variableDebtFormatted: debtData.variableDebtFormatted || '0.00',
      stableDebtSupply: debtData.stableDebtSupply || '0',
      stableDebtFormatted: debtData.stableDebtFormatted || '0.00',
      totalDebtSupply: debtData.totalDebtSupply || '0',
      totalDebtFormatted: debtData.totalDebtFormatted || '0.00',
      stableDebtTokenAddress: reserve.stableDebtTokenAddress,
      variableDebtTokenAddress: reserve.variableDebtTokenAddress,
      interestRateStrategyAddress: reserve.interestRateStrategyAddress,
      accruedToTreasury: reserve.accruedToTreasury.toString(),
      unbacked: reserve.unbacked.toString(),
      isolationModeTotalDebt: reserve.isolationModeTotalDebt.toString(),
      configurationData: reserve.configuration.data.toString()
    };
  });

  console.log(`✓ 数据整合完成，共 ${mergedData.length} 条记录`);
  return { mergedData };
}

/**
 * 步骤7: 导出到 Excel
 */
async function exportToExcel(context) {
  const { mergedData, chainId, outputDir = __dirname } = context;
  
  if (!mergedData || mergedData.length === 0) {
    console.log('⚠ 没有数据可导出');
    return;
  }

  console.log('正在生成 Excel 文件...');
  
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('AAVE Reserves');

  // 自动从数据中提取 key 作为表头
  const keys = Object.keys(mergedData[0]);
  worksheet.columns = keys.map(key => ({
    header: key,
    key: key,
    width: 25
  }));

  // 设置表头样式
  worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF4472C4' }
  };
  worksheet.getRow(1).alignment = { vertical: 'middle', horizontal: 'center' };

  // 添加数据
  mergedData.forEach((item) => {
    const row = worksheet.addRow(item);
    if (row.number % 2 === 0) {
      row.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFF2F2F2' }
      };
    }
  });

  // 生成文件名
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const chainNames = {
    1: 'ethereum', 56: 'bsc', 137: 'polygon',
    43114: 'avalanche', 42161: 'arbitrum', 10: 'optimism', 250: 'fantom'
  };
  const chainName = `${chainNames[chainId] || 'chain'}-${chainId}`;
  const filename = `aave_reserves_${chainName}_${timestamp}.xlsx`;
  const filePath = path.join(outputDir, filename);

  await workbook.xlsx.writeFile(filePath);
  console.log(`✓ Excel 文件已保存: ${filePath}`);
  
  return { excelFilePath: filePath };
}

module.exports = {
  initAAVE,
  fetchReservesList,
  fetchReserveData,
  fetchTokenInfo,
  fetchATokenBalances,
  fetchDebtTokenSupplies,
  fetchInterestRateStrategyParams,
  mergeData,
  exportToExcel
};
