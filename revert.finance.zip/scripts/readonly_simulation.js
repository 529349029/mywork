/**
 * 只读模拟：查看 Pool 状态和计算预期输出
 * 不需要钱包私钥，任何人都可以运行
 */

const { Web3 } = require('web3');

// 多个 RPC 节点，避免速率限制
const RPC_URLS = [
    'https://base.publicnode.com',
    'https://mainnet.base.org',
    'https://base.llamarpc.com',
    
    'https://1rpc.io/base'
];

const POOL_ADDRESS = '0xb2cc224c1c9fee385f8ad6a55b4d94e92359dc59';

const POOL_ABI = [
    {
        "inputs": [],
        "name": "slot0",
        "outputs": [
            { "internalType": "uint160", "name": "sqrtPriceX96", "type": "uint160" },
            { "internalType": "int24", "name": "tick", "type": "int24" },
            { "internalType": "uint16", "name": "observationIndex", "type": "uint16" },
            { "internalType": "uint16", "name": "observationCardinality", "type": "uint16" },
            { "internalType": "uint16", "name": "observationCardinalityNext", "type": "uint16" },
            { "internalType": "bool", "name": "unlocked", "type": "bool" }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token0",
        "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "token1",
        "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "liquidity",
        "outputs": [{ "internalType": "uint128", "name": "", "type": "uint128" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "fee",
        "outputs": [{ "internalType": "uint24", "name": "", "type": "uint24" }],
        "stateMutability": "view",
        "type": "function"
    }
];

const ERC20_ABI = [
    {
        "inputs": [],
        "name": "symbol",
        "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "decimals",
        "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }],
        "stateMutability": "view",
        "type": "function"
    }
];

async function readonlySimulation() {
    console.log('🔍 CLPool 只读模拟分析\n');
    console.log('=' .repeat(60));
    
    // 尝试多个 RPC
    let web3;
    let connectedUrl;
    
    for (const rpcUrl of RPC_URLS) {
        try {
            console.log(`🔄 尝试连接: ${rpcUrl}...`);
            const testWeb3 = new Web3(rpcUrl);
            await testWeb3.eth.getBlockNumber();
            web3 = testWeb3;
            connectedUrl = rpcUrl;
            console.log(`✅ 连接成功!\n`);
            break;
        } catch (error) {
            console.log(`❌ 失败: ${error.message}\n`);
        }
    }
    
    if (!web3) {
        throw new Error('所有 RPC 节点都不可用，请稍后重试');
    }
    const poolContract = new web3.eth.Contract(POOL_ABI, POOL_ADDRESS);
    
    // 1. 获取池子基本信息
    console.log('\n📊 步骤 1: 读取池子状态...\n');
    
    const [token0Addr, token1Addr, slot0, liquidity, fee] = await Promise.all([
        poolContract.methods.token0().call(),
        poolContract.methods.token1().call(),
        poolContract.methods.slot0().call(),
        poolContract.methods.liquidity().call(),
        poolContract.methods.fee().call()
    ]);
    
    console.log(`Pool 地址: ${POOL_ADDRESS}`);
    console.log(`Token0:    ${token0Addr}`);
    console.log(`Token1:    ${token1Addr}`);
    console.log(`当前 Tick: ${slot0.tick}`);
    console.log(`流动性:    ${liquidity}`);
    console.log(`费率:      ${Number(fee) / 10000}%`); // fee 是 basis points
    console.log(`池子状态:  ${slot0.unlocked ? '✅ Unlocked' : '❌ Locked'}`);
    
    // 2. 获取代币信息
    console.log('\n📊 步骤 2: 代币信息...\n');
    
    const token0Contract = new web3.eth.Contract(ERC20_ABI, token0Addr);
    const token1Contract = new web3.eth.Contract(ERC20_ABI, token1Addr);
    
    // 添加延迟避免速率限制
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const [token0Symbol, token1Symbol, token0Decimals, token1Decimals] = await Promise.all([
        token0Contract.methods.symbol().call(),
        token1Contract.methods.symbol().call(),
        token0Contract.methods.decimals().call(),
        token1Contract.methods.decimals().call()
    ]);
    
    console.log(`Token0: ${token0Symbol} (${token0Decimals} decimals)`);
    console.log(`Token1: ${token1Symbol} (${token1Decimals} decimals)`);
    
    // 3. 计算当前价格
    console.log('\n📊 步骤 3: 价格计算...\n');
    
    const sqrtPriceX96 = BigInt(slot0.sqrtPriceX96);
    const Q96 = BigInt(2) ** BigInt(96);
    
    // 价格 = (sqrtPrice / 2^96)^2
    const priceRatio = Number(sqrtPriceX96) / Number(Q96);
    const currentPrice = priceRatio * priceRatio;
    
    console.log(`SqrtPriceX96: ${slot0.sqrtPriceX96}`);
    console.log(`当前价格:     1 ${token0Symbol} = ${currentPrice.toFixed(6)} ${token1Symbol}`);
    console.log(`              1 ${token1Symbol} = ${(1/currentPrice).toFixed(6)} ${token0Symbol}`);
    
    // 4. 模拟不同交易量的输出
    console.log('\n📊 步骤 4: 模拟交易场景...\n');
    
    const scenarios = [
        { name: '小额交易', amount: '0.001' },
        { name: '中等交易', amount: '0.01' },
        { name: '大额交易', amount: '0.1' },
        { name: '超大额交易', amount: '1.0' }
    ];
    
    console.log('假设卖出 Token0 → 买入 Token1:\n');
    console.log('┌──────────────┬──────────────┬──────────────┬──────────────┐');
    console.log('│ 交易场景     │ 卖出数量     │ 预估买入     │ 价格影响     │');
    console.log('├──────────────┼──────────────┼──────────────┼──────────────┤');
    
    for (const scenario of scenarios) {
        const amountIn = web3.utils.toWei(scenario.amount, 'ether');
        
        // 简化估算（实际应该使用 SwapMath.computeSwapStep）
        // 这里只用恒定乘积公式近似：x * y = k
        const amountInNum = Number(scenario.amount);
        const estimatedOut = amountInNum * currentPrice * (1 - Number(fee)/1000000); // 扣除手续费
        
        // 价格影响估算（简化）
        const priceImpact = (amountInNum / (Number(liquidity) / 1e18)) * 100;
        
        console.log(`│ ${scenario.name.padEnd(10)} │ ${scenario.amount.padStart(10)} ${token0Symbol.substring(0,3)} │ ${estimatedOut.toFixed(6).padStart(10)} ${token1Symbol.substring(0,3)} │ ${priceImpact.toFixed(2).padStart(8)}%   │`);
    }
    
    console.log('└──────────────┴──────────────┴──────────────┴──────────────┘\n');
    
    console.log('⚠️  注意: 以上为简化估算，实际输出需要考虑:');
    console.log('   - Tick 边界的流动性变化');
    console.log('   - 精确的 SwapMath 计算');
    console.log('   - Gas 费用影响\n');
    
    // 5. 查看最近的交易
    console.log('📊 步骤 5: 查看链上交易...\n');
    console.log(`在 BaseScan 查看实时交易:`);
    console.log(`https://basescan.org/address/${POOL_ADDRESS}#transactions\n`);
    
    console.log('💡 如何执行真实交易:\n');
    console.log('1️⃣  通过 Router 合约（推荐）:');
    console.log('   - Router 会处理 callback');
    console.log('   - 自动计算最优路径');
    console.log('   - 提供滑点保护\n');
    
    console.log('2️⃣  直接调用 Pool（需要实现 callback）:');
    console.log('   - 你的合约必须实现 ICLSwapCallback 接口');
    console.log('   - 在 uniswapV3SwapCallback 中转入代币');
    console.log('   - 适合高级用户和套利机器人\n');
    
    console.log('3️⃣  使用 Revert Finance UI:');
    console.log('   - https://revert.finance/');
    console.log('   - 图形界面，最简单\n');
    
    console.log('=' .repeat(60));
    console.log('✅ 只读模拟完成！\n');
    
    // 6. 关键参数说明
    console.log('📚 关键参数解释:\n');
    console.log('• sqrtPriceX96:');
    console.log('  - 价格的平方根 × 2^96');
    console.log('  - 用于高精度计算');
    console.log('  - 实际价格 = (sqrtPriceX96 / 2^96)^2\n');
    
    console.log('• tick:');
    console.log('  - 离散化的价格刻度');
    console.log('  - 每个 tick 对应一个价格');
    console.log('  - tick spacing 决定粒度\n');
    
    console.log('• liquidity:');
    console.log('  - 当前活跃的流动性总量');
    console.log('  - 跨越 tick 时会变化');
    console.log('  - 影响价格滑点\n');
    
    console.log('• zeroForOne:');
    console.log('  - true:  卖出 Token0，买入 Token1');
    console.log('  - false: 卖出 Token1，买入 Token0\n');
    
    console.log('• amountSpecified:');
    console.log('  - > 0: 精确输入（我想卖出 X）');
    console.log('  - < 0: 精确输出（我想买入 X）\n');
    
    console.log('• sqrtPriceLimitX96:');
    console.log('  - 价格限制，防止过大滑点');
    console.log('  - zeroForOne 时必须 < 当前价格');
    console.log('  - oneForZero 时必须 > 当前价格\n');
}

readonlySimulation().catch(error => {
    console.error('\n❌ 错误:', error.message);
    console.error(error.stack);
});
