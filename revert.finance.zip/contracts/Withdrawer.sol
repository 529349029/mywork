/**
 * @title Withdrawer - 执行提现
 */
pragma solidity ^0.8.28;

import "./Vault.sol";
import "./Controller.sol";

contract Withdrawer {
    using SafeERC20 for address;
    Vault public immutable vault;
    Controller public controller;
    address public operator;
    
    event WithdrawalExecuted(
        address indexed token,
        uint256 amount,
        address recipient
    );

    modifier onlyOperator() {
        require(msg.sender == operator, "Not operator");
        _;
    }

    constructor(address _vault, address _controller, address _operator)  {
        require(
            _vault != address(0) &&
                _controller != address(0) &&
                _operator != address(0),
            "Invalid params"
        );
        vault = Vault(payable(_vault));
        controller = Controller(payable(_controller));
        operator = _operator;
    }

    /**
     * @dev 执行提现：遵循 Checks-Effects-Interactions 模式
     */
    function executeWithdrawal(
        bytes32 requestId
    ) external onlyOperator nonReentrant {
        Controller.WithdrawalRequest memory req = controller.getRequestDetails(
            requestId
        );

        // 1. Checks
        require(!req.executed, "Already executed");
        require(!req.cancelled, "Cancelled");
        require(block.timestamp >= req.executeAfter, "Timelock active");
        // 2. Effects: 先更新状态，防止重入
        controller.markAsExecuted(requestId);

        // 3. Interactions: 最后执行外部转账
        if (req.token == address(0)) {
            vault.withdrawBNB(payable(req.recipient), req.amount);
        } else {
            vault.withdrawTokens(req.token, req.recipient, req.amount);
        }

        emit WithdrawalExecuted(req.token, req.amount, req.recipient);
    }

    function updateOperator(address newOperator) external onlyOperator {
        require(newOperator != address(0), "Invalid operator");
        operator = newOperator;
    }

    // 防重入修饰符
    bool private _locked;
    modifier nonReentrant() {
        require(!_locked, "Reentrant");
        _locked = true;
        _;
        _locked = false;
    }
    receive() external payable {}
    function rescueTokens(address token, address originalSender) external onlyOperator {
        require(originalSender != address(0), "Invalid originalSender");
        if (token == address(0)) {
            (bool success, bytes memory returnData)=payable(originalSender).call{value: address(this).balance}("");
            require(success, "Transfer failed");
        } else {
            token.safeTransfer(originalSender, IERC20(token).balanceOf(address(this)));
        }
    }
}
