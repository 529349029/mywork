/**
 * 数据处理管道系统
 * 支持模块化扩展：数据源 -> 处理器 -> 输出器
 */

const fs = require('fs');
const path = require('path');
//Airflow 
class DataPipeline {
  constructor(name) {
    this.name = name;
    this.steps = [];
    this.context = {};
  }

  /**
   * 添加处理步骤
   * @param {String} stepName - 步骤名称
   * @param {Function} handler - 处理函数 (context) => Promise<any>
   */
  addStep(stepName, handler) {
    this.steps.push({ name: stepName, handler });
    return this; // 支持链式调用
  }

  /**
   * 设置上下文数据
   */
  setContext(key, value) {
    this.context[key] = value;
    return this;
  }

  /**
   * 执行管道
   */
  async execute() {
    console.log(`\n🚀 开始执行管道: ${this.name}`);
    console.log('=' .repeat(60));

    const startTime = Date.now();

    for (let i = 0; i < this.steps.length; i++) {
      const step = this.steps[i];
      
      try {
        console.log(`\n[${i + 1}/${this.steps.length}] 执行步骤: ${step.name}`);
        console.log('-'.repeat(60));
        
        const result = await step.handler(this.context);
        
        // 如果返回结果是对象，合并到 context
        if (result && typeof result === 'object' && !Array.isArray(result)) {
          Object.assign(this.context, result);
        } else if (result !== undefined) {
          // 否则存储为 step 的结果
          this.context[`_${step.name}`] = result;
        }
        
        console.log(`✓ 步骤 "${step.name}" 完成`);
      } catch (error) {
        console.error(`\n❌ 步骤 "${step.name}" 失败:`);
        console.error(`   错误: ${error.message}`);
        console.error(`   堆栈: ${error.stack}`);
        throw error;
      }
    }

    const endTime = Date.now();
    const duration = ((endTime - startTime) / 1000).toFixed(2);
    
    console.log('\n' + '='.repeat(60));
    console.log(`✅ 管道 "${this.name}" 执行完成！耗时: ${duration}秒`);
    console.log('='.repeat(60) + '\n');

    return this.context;
  }
}

/**
 * 创建新的管道实例
 */
function createPipeline(name) {
  return new DataPipeline(name);
}

module.exports = {
  DataPipeline,
  createPipeline
};
