/**
 * Excel 转 Markdown 模块
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const execAsync = promisify(exec);

/**
 * 步骤: 将 Excel 转换为 Markdown
 */
async function convertExcelToMarkdown(context) {
  const { excelFilePath, outputDir = path.dirname(excelFilePath) } = context;
  
  if (!excelFilePath) {
    throw new Error('缺少 excelFilePath，请先执行导出 Excel 步骤');
  }

  if (!fs.existsSync(excelFilePath)) {
    throw new Error(`Excel 文件不存在: ${excelFilePath}`);
  }

  // 生成输出文件路径
  const basename = path.basename(excelFilePath, path.extname(excelFilePath));
  const markdownPath = path.join(outputDir, `${basename}.md`);

  console.log(`🔄 正在转换 Excel 到 Markdown...`);
  console.log(`   输入: ${excelFilePath}`);
  console.log(`   输出: ${markdownPath}`);

  try {
    // 调用 markitdown
    const command = `markitdown "${excelFilePath}"`;
    const { stdout } = await execAsync(command);

    // 写入文件
    fs.writeFileSync(markdownPath, stdout, 'utf-8');
    
    console.log(`✅ Markdown 文件已保存: ${markdownPath}`);
    console.log(`📊 内容长度: ${stdout.length} 字符`);

    return { markdownFilePath: markdownPath };
  } catch (error) {
    console.error(`❌ 转换失败: ${error.message}`);
    if (error.stderr) {
      console.error(`错误详情: ${error.stderr}`);
    }
    throw error;
  }
}

module.exports = {
  convertExcelToMarkdown
};
