/**
 * @title Controller - 提现控制器
 */
pragma solidity ^0.8.28;

// pragma experimental ABIEncoderV2;
import "./Vault.sol";

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }
}

contract Controller {
    using SafeMath for uint256;
    using SafeERC20 for address;

    Vault public immutable vault;
    address public owner;
    // address public authorizedWithdrawer;
    //这里要求必须是多签，只做一件事情，修改取款者withdrawer，不是取钱
    address public gnosisSafeAdminAddr;
    // 锁定状态
    struct TokenLock {
        uint256 unlockTime;
        bool isLocked;
    }
    struct PendingLimitChange {
        uint256 newLimit;
        uint256 effectiveAfter;
        bool exists;
    }
    mapping(address => TokenLock) public tokenLocks;
    mapping(address => PendingLimitChange) public pendingLimitChanges;
    uint256 public constant LIMIT_CHANGE_DELAY = 48 hours; // 48小时延迟
    address[] public lockedTokens;

    // 提现请求
    struct WithdrawalRequest {
        address token;
        uint256 amount;
        address recipient;
        uint256 requestTime;
        uint256 executeAfter;
        bool executed;
        bool cancelled;
    }
    mapping(bytes32 => WithdrawalRequest) public withdrawalRequests;
    bytes32[] public requestIds;

    // 按代币的每日限额
    mapping(address => uint256) public tokenDailyLimit;
    mapping(address => uint256) public tokenWithdrawnToday;
    mapping(address => uint256) public lastTokenResetDay;

    uint256 public withdrawalDelay;
    event WithdrawalCancelled(bytes32 indexed requestId);
    event TokenLocked(address indexed token, uint256 unlockTime);
    event WithdrawalRequested(
        bytes32 indexed requestId,
        address token,
        uint256 amount,
        address recipient
    );
    event WithdrawalExecuted(bytes32 indexed requestId);
    event TokenLimitSet(address indexed token, uint256 limit);
    event WithdrawerRotated(
        address indexed newWithdrawer,
        address indexed newOwner
    );
    event TokenLimitChangeRequested(
        address indexed token,
        uint256 newLimit,
        uint256 effectiveAfter
    );
    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }
    modifier onlyGnosisSafeAdminAddr() {
        require(msg.sender == gnosisSafeAdminAddr, "Not gnosisSafeAdminAddr");
        _;
    }

    modifier onlyWithdrawer() {
        require(vault.authorizedWithdrawers(msg.sender), "Not withdrawer");
        _;
    }

    constructor(
        address _vault,
        address _owner,
        uint256 _delay,
        address _gnosisSafeAdminAddr
    ) {
        // require(_gnosisSafeAdminAddr != address(0), "Invalid withdrawer");
        require(
            _vault != address(0) &&
                _owner != address(0) &&
                _gnosisSafeAdminAddr != address(0),
            "address 0"
        );
        require(_delay >= 1 hours, "Delay too short");
        vault = Vault(payable(_vault));
        owner = _owner;
        withdrawalDelay = _delay;
        gnosisSafeAdminAddr = _gnosisSafeAdminAddr;
    }

    function getRequestIdsCount() public view returns (uint256) {
        return requestIds.length;
    }

    function getLockedTokensCount() public view returns (uint256) {
        return lockedTokens.length;
    }

    //通过地址 0x0000000000000000000000000000000000000000 锁定BNB
    //这里限制最长锁定时间是10年，防止误操作，一旦设置，锁定期内不可修改
    //unlockTime 指的是秒，秒级时间戳，不是毫秒，到了哪一年的秒级时间戳
    function lockToken(address token, uint256 unlockTime) external onlyOwner {
        require(canWithdraw(token), "Already locked");
        require(unlockTime > block.timestamp, "Time must be future");
        require(
            unlockTime <= block.timestamp + 10 * 365 * 24 * 60 * 60,
            "Time must be within 10 years"
        );
        
        // 只在首次锁定时添加到列表（检查旧状态）
        bool isFirstLock = !tokenLocks[token].isLocked;
        
        tokenLocks[token] = TokenLock({unlockTime: unlockTime, isLocked: true});
        
        if (isFirstLock) {
            lockedTokens.push(token);
        }
        
        emit TokenLocked(token, unlockTime);
    }

    function canWithdraw(address token) public view returns (bool) {
        TokenLock storage lock = tokenLocks[token];
        return !lock.isLocked || block.timestamp >= lock.unlockTime;
    }

    function requestWithdrawal(
        address token,
        uint256 amount,
        address recipient
    ) external onlyOwner {
        require(amount > 0 && recipient != address(0), "Invalid params");
        require(canWithdraw(token), "Token still locked");
        require(
            vault.getTokenBalance(token) >= amount,
            "Insufficient vault balance"
        );

        checkAndUpdateDailyLimit(token, amount);

        bytes32 requestId = keccak256(
            abi.encodePacked(
                token,
                amount,
                recipient,
                block.timestamp,
                requestIds.length
            )
        );
        withdrawalRequests[requestId] = WithdrawalRequest({
            token: token,
            amount: amount,
            recipient: recipient,
            requestTime: block.timestamp,
            executeAfter: block.timestamp + withdrawalDelay,
            executed: false,
            cancelled: false
        });
        requestIds.push(requestId);

        emit WithdrawalRequested(requestId, token, amount, recipient);
        // return requestId;
    }

    function cancelWithdrawal(bytes32 requestId) external onlyOwner {
        WithdrawalRequest storage req = withdrawalRequests[requestId];
        require(!req.executed, "Already executed");
        require(!req.cancelled, "Already cancelled");

        req.cancelled = true;
        emit WithdrawalCancelled(requestId);
    }

    function checkAndUpdateDailyLimit(address token, uint256 amount) internal {
        uint256 today = block.timestamp / 1 days;
        if (lastTokenResetDay[token] != today) {
            tokenWithdrawnToday[token] = 0;
            lastTokenResetDay[token] = today;
        }
        uint256 limit = tokenDailyLimit[token];
        require(limit > 0, "No limit set for this token");
        require(
            tokenWithdrawnToday[token].add(amount) <= limit,
            "Daily limit exceeded"
        );
        tokenWithdrawnToday[token] = tokenWithdrawnToday[token].add(amount);
    }

    function markAsExecuted(bytes32 requestId) external onlyWithdrawer {
        WithdrawalRequest storage req = withdrawalRequests[requestId];
        require(!req.executed && !req.cancelled, "Invalid state");
        req.executed = true;
        emit WithdrawalExecuted(requestId);
    }

    // 修改 setTokenDailyLimit
    function setTokenDailyLimit(
        address token,
        uint256 limit
    ) external onlyOwner {
        require(limit > 0, "Invalid limit");

        // 如果新限额 <= 当前限额或者首次设置，立即生效（降低限额不需要等待）
        if (limit <= tokenDailyLimit[token] || tokenDailyLimit[token] == 0) {
            tokenDailyLimit[token] = limit;
            emit TokenLimitSet(token, limit);
        } else {
            // 提高限额需要等待
            pendingLimitChanges[token] = PendingLimitChange({
                newLimit: limit,
                effectiveAfter: block.timestamp + LIMIT_CHANGE_DELAY,
                exists: true
            });
            emit TokenLimitChangeRequested(
                token,
                limit,
                block.timestamp + LIMIT_CHANGE_DELAY
            );
        }
    }

    // 应用待处理的限额变更
    function applyPendingLimitChange(
        address token
    ) external onlyGnosisSafeAdminAddr {
        PendingLimitChange storage change = pendingLimitChanges[token];
        require(change.exists, "No pending change");
        require(
            block.timestamp >= change.effectiveAfter,
            "Wait period not passed"
        );

        tokenDailyLimit[token] = change.newLimit;
        change.exists = false;
        emit TokenLimitSet(token, change.newLimit);
    }

    function updateWithdrawer(
        address newWithdrawer,
        bool newWithdrawerAuthorized,
        address _newowner,
        bool _newownerAuthorized
    ) external onlyGnosisSafeAdminAddr {
        require(newWithdrawer != address(0), "zero address");
        require(_newowner != address(0), "zero address");
        if (newWithdrawerAuthorized) {
            require(
                newWithdrawer.code.length > 0,
                "Address must be a contract"
            );
        }
        vault.setWithdrawerAuthorization(
            newWithdrawer,
            newWithdrawerAuthorized
        );
        if (_newownerAuthorized) {
            owner = _newowner;//这个是自己的地址
        }
        //这里emit只是起到一个提醒有人在修改的作用
        emit WithdrawerRotated(newWithdrawer, _newowner);
    }

    /**
     * @dev Admin 更换 Admin
     */
    function transferGnosisSafeAdminAddrship(
        address newGnosisSafeAdminAddr
    ) external onlyGnosisSafeAdminAddr {
        require(
            newGnosisSafeAdminAddr != address(0),
            "Invalid newgnosisSafeAdminAddr"
        );
        gnosisSafeAdminAddr = newGnosisSafeAdminAddr;
    }

    function getRequestDetails(
        bytes32 requestId
    ) external view returns (WithdrawalRequest memory) {
        return withdrawalRequests[requestId];
    }

    receive() external payable {}

    function rescueTokens(
        address token,
        address originalSender
    ) external onlyOwner {
        require(originalSender != address(0), "Invalid originalSender");
        if (token == address(0)) {
            (bool success, bytes memory returnData) = payable(originalSender)
                .call{value: address(this).balance}("");
            require(success, "Transfer failed");
        } else {
            token.safeTransfer(
                originalSender,
                IERC20(token).balanceOf(address(this))
            );
        }
    }
}
